(function ($) {
    "use strict";

    Object.assign(window.ReyhanApp, {
        fileQueue: [],

        showNotification: function (msg, type = 'info') {
            $('.rp-notification-toast').remove();
            var icon = (type === 'success') ? 'dashicons-yes' : 'dashicons-warning';
            var $toast = $('<div class="rp-notification-toast rp-toast-' + type + '">' +
                '<span class="dashicons ' + icon + '"></span> ' + msg +
                '</div>');
            $('body').append($toast);
            setTimeout(function () { $toast.addClass('show'); }, 10);
            setTimeout(function () {
                $toast.removeClass('show');
                setTimeout(function () { $toast.remove(); }, 300);
            }, 4000);
        },

        initTickets: function () {
            console.log('ReyhanPanel: Tickets System Active');

            if ($('#rp-user-tickets-list').length > 0) {
                this.loadTickets(1);
            }

            $(document).off('click', '#btn-refresh-tickets').on('click', '#btn-refresh-tickets', (e) => {
                e.preventDefault();
                this.loadTickets(1);
            });

            $(document).off('click', '.rp-btn-new-ticket-full').on('click', '.rp-btn-new-ticket-full', function (e) {
                e.preventDefault();
                $('#rp-ticket-creation-area').slideToggle();
            });

            $(document).off('click', '.rp-btn-back-list').on('click', '.rp-btn-back-list', function (e) {
                e.preventDefault();
                $('#rp-new-ticket-form, #rp-single-ticket-container').slideUp();
                $('#rp-user-tickets-list, .rp-ticket-header-wrapper').slideDown();
                $('#rp-ticket-creation-area').slideUp();
            });

            $(document).off('submit', '#rp-ticket-submit-form').on('submit', '#rp-ticket-submit-form', (e) => {
                e.preventDefault();
                this.submitNewTicket();
            });

            $(document).off('submit', '#rp-form-reply-ticket').on('submit', '#rp-form-reply-ticket', (e) => {
                e.preventDefault();
                this.replyTicket();
            });

            if ($('#rp-user-tickets-list').length > 0) this.loadTickets(1);

            $(document).off('click', '#btn-refresh-tickets').on('click', '#btn-refresh-tickets', (e) => { e.preventDefault(); this.loadTickets(1); });
            $(document).off('click', '.rp-btn-new-ticket-full').on('click', '.rp-btn-new-ticket-full', (e) => { e.preventDefault(); $('#rp-ticket-creation-area').slideToggle(); });
            $(document).off('click', '.rp-btn-back-list').on('click', '.rp-btn-back-list', (e) => {
                e.preventDefault();
                $('#rp-new-ticket-form, #rp-single-ticket-container').slideUp();
                $('#rp-user-tickets-list, .rp-ticket-header-wrapper').slideDown();
                $('#rp-ticket-creation-area').slideUp();
            });

            // سابمیت‌ها
            $(document).off('submit', '#rp-ticket-submit-form').on('submit', '#rp-ticket-submit-form', (e) => { e.preventDefault(); this.submitNewTicket(); });
            $(document).off('submit', '#rp-form-reply-ticket').on('submit', '#rp-form-reply-ticket', (e) => { e.preventDefault(); this.replyTicket(); });

            // *** مدیریت آپلود چندگانه ***
            this.initMultiUpload();
        },

        initMultiUpload: function () {
            var self = this;

            // رویداد تغییر اینپوت فایل (انتخاب فایل جدید)
            $(document).on('change', '.rp-hidden-file-input', function () {
                var input = this;
                if (input.files && input.files.length > 0) {
                    var newFiles = Array.from(input.files);

                    // بررسی محدودیت ۵ فایل
                    if (self.fileQueue.length + newFiles.length > 5) {
                        self.showNotification('شما حداکثر می‌توانید ۵ فایل آپلود کنید.', 'error');
                        input.value = ''; // ریست کردن اینپوت
                        return;
                    }

                    // اعتبارسنجی تک تک فایل‌ها
                    var validFiles = newFiles.filter(f => self.validateFileObj(f));

                    // افزودن فایل‌های معتبر به صف
                    validFiles.forEach(f => self.fileQueue.push(f));

                    // رندر کردن لیست
                    self.renderFileQueue();
                    input.value = ''; // ریست کردن اینپوت برای انتخاب بعدی
                }
            });

            // رویداد حذف فایل از صف
            $(document).on('click', '.rp-fq-remove', function () {
                var idx = $(this).data('index');
                self.fileQueue.splice(idx, 1); // حذف از آرایه
                self.renderFileQueue(); // رندر مجدد
            });
        },

        renderFileQueue: function () {
            var $container = $('.rp-file-list-queue');
            $container.empty(); // پاک کردن لیست فعلی

            if (this.fileQueue.length === 0) return;

            this.fileQueue.forEach((file, index) => {
                // تبدیل سایز به کیلوبایت
                var sizeKb = Math.round(file.size / 1024);

                var html = `
                    <div class="rp-file-queue-item">
                        <div class="rp-fq-info">
                            <span class="dashicons dashicons-media-default rp-fq-icon"></span>
                            <span class="rp-fq-name">${file.name}</span>
                            <span style="font-size:11px; color:#999;">(${sizeKb} KB)</span>
                        </div>
                        <button type="button" class="rp-fq-remove" data-index="${index}" title="حذف فایل">
                            <span class="dashicons dashicons-no"></span>
                        </button>
                    </div>
                `;
                $container.append(html);
            });
        },

        validateFileObj: function (file) {
            var ext = file.name.split('.').pop().toLowerCase();
            // لیست سیاه امنیتی
            var blockedExts = ['php', 'exe', 'js', 'bat', 'sh', 'phtml', 'phar', 'vbs', 'cmd', 'svg', 'htaccess', 'ini', 'config'];

            if (blockedExts.includes(ext)) {
                this.showNotification('فایل ' + file.name + ' امنیتی غیرمجاز است.', 'error');
                return false;
            }

            // لیست سفید (از تنظیمات PHP)
            if (typeof reyhan_front_obj.allowed_extensions !== 'undefined' && reyhan_front_obj.allowed_extensions.length > 0) {
                var allowed = reyhan_front_obj.allowed_extensions.split(',').map(item => item.trim().toLowerCase());
                if (!allowed.includes(ext)) {
                    this.showNotification('فرمت فایل ' + ext + ' مجاز نیست.', 'error');
                    return false;
                }
            }

            // بررسی حجم
            var maxMb = (typeof reyhan_front_obj.max_file_size !== 'undefined') ? parseFloat(reyhan_front_obj.max_file_size) : 2;
            if (file.size > maxMb * 1024 * 1024) {
                this.showNotification('حجم فایل ' + file.name + ' بیشتر از حد مجاز است.', 'error');
                return false;
            }
            return true;
        },

        loadTickets: function (page) {
            var container = $('#rp-user-tickets-list');
            container.html('<div class="rp-loading-spinner" style="margin:20px auto;"></div>');

            $.post(reyhan_front_obj.ajax_url, {
                action: 'reyhan_user_list_tickets',
                security: reyhan_front_obj.nonce,
                paged: page
            }, (res) => {
                if (res.success) {
                    container.html(res.data.html);
                } else {
                    container.html('<div class="rp-error-msg">' + (res.data || 'خطا') + '</div>');
                }
            }).fail((xhr) => {
                container.html('<div class="rp-error-msg">خطای ارتباط با سرور</div>');
            });
        },

        loadSingleTicket: function (tid) {
            // ریست کردن صف هنگام باز کردن تیکت جدید
            this.fileQueue = [];
            this.renderFileQueue();

            $('#rp-user-tickets-list, .rp-ticket-header-wrapper, #rp-ticket-creation-area').slideUp();
            if ($('#rp-single-ticket-container').length === 0) {
                var mainContainer = $('#rp-user-tickets-list').parent();
                if (!mainContainer.length) mainContainer = $('body');
                mainContainer.append('<div id="rp-single-ticket-container"></div>');
            }
            $('#rp-single-ticket-container').html('<div class="rp-loading-spinner" style="margin:50px auto;"></div>').slideDown();

            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_view_ticket', security: reyhan_front_obj.nonce, ticket_id: tid }, (res) => {
                if (res.success) {
                    $('#rp-single-ticket-container').html(res.data);

                    // چون فرم پاسخ به صورت AJAX لود شده، باید کانتینر صف را برایش آماده کنیم (اگر در HTML نباشد)
                    // (البته ما در HTML اضافه کردیم، ولی این محض اطمینان است)

                    var chatBox = $('.rp-chat-box');
                    if (chatBox.length) chatBox.scrollTop(chatBox[0].scrollHeight);
                } else {
                    this.showNotification(res.data, 'error'); $('.rp-btn-back-list').click();
                }
            });
        },

        closeTicket: function (tid) {
            if (!confirm('آیا مطمئن هستید؟')) return;
            $.post(reyhan_front_obj.ajax_url, {
                action: 'reyhan_user_close', security: reyhan_front_obj.nonce, ticket_id: tid
            }, (res) => {
                if (res.success) {
                    this.showNotification('تیکت بسته شد', 'success');
                    this.loadSingleTicket(tid);
                } else {
                    this.showNotification(res.data, 'error');
                }
            });
        },

        validateFile: function (fileInput) {
            if (fileInput && fileInput.files.length > 0) {
                var file = fileInput.files[0];
                var ext = file.name.split('.').pop().toLowerCase();

                var blockedExts = ['php', 'exe', 'js', 'bat', 'sh', 'phtml', 'phar', 'vbs', 'cmd', 'svg', 'htaccess', 'ini', 'config'];
                if (blockedExts.includes(ext)) {
                    this.showNotification('خطای امنیتی: آپلود این نوع فایل مجاز نیست.', 'error');
                    return false; // توجه: ریست کردن در تابع فراخوان انجام می‌شود
                }

                if (typeof reyhan_front_obj.allowed_extensions !== 'undefined' && reyhan_front_obj.allowed_extensions.length > 0) {
                    var allowed = reyhan_front_obj.allowed_extensions.split(',').map(item => item.trim().toLowerCase());
                    if (!allowed.includes(ext)) {
                        this.showNotification('فرمت فایل مجاز نیست. فرمت‌های مجاز: ' + reyhan_front_obj.allowed_extensions, 'error');
                        return false;
                    }
                }

                var maxMb = (typeof reyhan_front_obj.max_file_size !== 'undefined') ? parseFloat(reyhan_front_obj.max_file_size) : 2;
                if (file.size > maxMb * 1024 * 1024) {
                    this.showNotification('حجم فایل بیشتر از حد مجاز (' + maxMb + ' مگابایت) است.', 'error');
                    return false;
                }
            }
            return true;
        },

        submitNewTicket: function () {
            var $form = $('#rp-ticket-submit-form');
            var formData = new FormData($form[0]);

            var title = (formData.get('title') || '').trim();
            var msg = (formData.get('message') || '').trim();

            if (!title) { this.showNotification('موضوع تیکت الزامی است.', 'error'); return; }
            if (!isNaN(title)) { this.showNotification('موضوع نمی‌تواند فقط عدد باشد.', 'error'); return; }
            if (msg.length < 5) { this.showNotification('متن تیکت کوتاه است.', 'error'); return; }

            // اضافه کردن فایل‌های داخل صف به formData
            this.fileQueue.forEach((file) => {
                formData.append('attachments[]', file); // نام آرایه‌ای برای PHP
            });

            formData.append('action', 'reyhan_user_create_ticket');
            formData.append('security', reyhan_front_obj.nonce);

            var $btn = $form.find('button[type="submit"]');
            var txt = $btn.text();
            $btn.text('در حال ارسال...').prop('disabled', true);

            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: formData,
                processData: false, contentType: false,
                success: (res) => {
                    $btn.text(txt).prop('disabled', false);
                    if (res.success) {
                        this.showNotification(res.data, 'success');
                        $form[0].reset();
                        this.fileQueue = []; this.renderFileQueue(); // پاکسازی صف
                        $('#rp-ticket-creation-area').slideUp();
                        this.loadTickets(1);
                    } else { this.showNotification(res.data, 'error'); }
                },
                error: (xhr) => { $btn.text(txt).prop('disabled', false); this.showNotification('خطای سرور', 'error'); }
            });
        },

        replyTicket: function () {
            var $form = $('#rp-form-reply-ticket');
            var formData = new FormData($form[0]);
            var msg = (formData.get('message') || '').trim();

            if (!msg) { this.showNotification('متن پاسخ خالی است.', 'error'); return; }
            if (msg.length < 20) { this.showNotification('متن پاسخ باید حداقل ۲۰ کاراکتر باشد.', 'error'); return; }

            // اضافه کردن فایل‌های صف
            this.fileQueue.forEach((file) => {
                formData.append('attachments[]', file);
            });

            formData.append('action', 'reyhan_user_reply_ticket');
            formData.append('security', reyhan_front_obj.nonce);

            var $btn = $form.find('button[type="submit"]');
            var txt = $btn.text();
            $btn.text('...').prop('disabled', true);

            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: formData,
                processData: false, contentType: false,
                success: (res) => {
                    $btn.text(txt).prop('disabled', false);
                    if (res.success) {
                        this.showNotification(res.data, 'success');
                        this.fileQueue = []; // پاکسازی صف
                        var tid = formData.get('ticket_id');
                        this.loadSingleTicket(tid);
                    } else { this.showNotification(res.data, 'error'); }
                },
                error: (xhr) => { $btn.text(txt).prop('disabled', false); this.showNotification('خطای سرور', 'error'); }
            });
        }
    });

    $(document).ready(function () {
        if (typeof ReyhanApp !== 'undefined') {
            ReyhanApp.initTickets();
        }
    });

})(jQuery);