jQuery(document).ready(function($) {
    
    // 1. Initialize Select2 with AJAX
    $('#rp-user-select').select2({
        dir: 'rtl',
        language: 'fa',
        ajax: {
            url: reyhan_pm_ajax.ajax_url,
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    action: 'reyhan_search_users', // نام اکشن PHP که در مرحله 1 ساختیم
                    security: reyhan_pm_ajax.search_nonce,
                    term: params.term
                };
            },
            processResults: function (data) {
                return {
                    results: data.results
                };
            },
            cache: true
        },
        placeholder: 'حداقل ۳ حرف تایپ کنید...',
        minimumInputLength: 3
    });

    // 2. Handle User Selection
    $('#rp-user-select').on('select2:select', function (e) {
        var data = e.params.data;
        var payload = data.payload;

        if ( payload ) {
            // Fill Info Card
            $('#u-name').text(payload.name);
            $('#u-email').text(payload.email);
            $('#u-mobile').text(payload.mobile);
            $('#u-img').attr('src', payload.avatar);
            $('#u-link').attr('href', 'user-edit.php?user_id=' + data.id);
            
            // Show Card with Animation
            $('#rp-user-info-card').slideDown();
        }
    });

    // 3. New Message Button (Reset)
    $('#btn-new-msg').on('click', function() {
        $('#rp-user-select').val(null).trigger('change');
        $('#rp-user-info-card').slideUp();
        $('#rp-personal-msg-form')[0].reset();
        $('.rp-msg-item').removeClass('active');
    });

    // 4. Sidebar Item Click (Simulation)
    $('.rp-msg-item').on('click', function() {
        $('.rp-msg-item').removeClass('active');
        $(this).addClass('active');
        // اینجا بعداً کد AJAX برای دریافت محتوای پیام قدیمی قرار می‌گیرد
        // فعلاً فقط فرم را برای نمایش پر می‌کنیم (دمو)
        // ...
    });
});