jQuery(document).ready(function($) {

    // متغیرهای سراسری (هماهنگ با HTML جدید)
    const searchInput = $('#rp-user-search-input');
    const resultsBox = $('#rp-user-search-results');
    const userCard = $('#rp-user-info-card');
    const hiddenInput = $('#selected_user_id');
    const msgForm = $('#rp-personal-msg-form');
    const modal = $('#rp-reset-confirm-modal');
    const searchWrapper = $('.rp-search-user-box'); // نگهدارنده اصلی برای مدیریت استایل
    
    let searchTimer;

    // --- تابع ریست کامل ---
    function resetFormComplete() {
        // 1. خالی کردن فیلدها
        $('#msg-title').val('');
        $('#msg-content').val('');
        $('#send_email_check').prop('checked', false);
        hiddenInput.val('');
        
        // 2. ریست کردن جستجو
        searchInput.val('');
        userCard.hide();
        searchWrapper.removeClass('user-selected'); // این کلاس اینپوت را دوباره نمایش می‌دهد
        
        // بازگرداندن متن لیبل به حالت اول
        $('#rp-search-label').text('گیرنده پیام').css('color', '');
        
        // 3. بستن پاپ‌آپ
        modal.removeClass('active');

        // 4. فوکس (اسکرول به بالا)
        $('html, body').animate({ scrollTop: 0 }, 300);
        setTimeout(() => searchInput.focus(), 350);
    }

    // --- باز کردن پاپ‌آپ ---
    function showModal() {
        modal.addClass('active');
    }

    // ============================================================
    // هندلر دکمه "نوشتن پیام جدید"
    // ============================================================
    $(document).on('click', '#btn-new-msg', function(e) {
        e.preventDefault();
        
        // بررسی پر بودن فیلدها
        const hasUser    = (hiddenInput.val() || '').trim() !== '';
        const hasTitle   = ($('#msg-title').val() || '').trim() !== '';
        const hasContent = ($('#msg-content').val() || '').trim() !== '';

        if ( hasUser || hasTitle || hasContent ) {
            if (modal.length > 0) {
                showModal();
            } else {
                // اگر به هر دلیلی مدال در صفحه نبود، مستقیم ریست کن
                if(confirm('آیا مطمئن هستید؟ اطلاعات فرم پاک خواهد شد.')) {
                    resetFormComplete();
                }
            }
        } else {
            resetFormComplete();
        }
    });

    // --- دکمه‌های داخل پاپ‌آپ ---
    $(document).on('click', '#btn-modal-confirm', function() {
        resetFormComplete();
    });

    $(document).on('click', '#btn-modal-cancel', function() {
        modal.removeClass('active');
    });

    // بستن با کلیک روی فضای تاریک
    $(document).on('click', '#rp-reset-confirm-modal', function(e) {
        if ($(e.target).is('#rp-reset-confirm-modal')) {
            $(this).removeClass('active');
        }
    });

    // ============================================================
    // بخش جستجو و انتخاب کاربر
    // ============================================================
    
    searchInput.on('input', function() {
        let term = $(this).val().trim();
        clearTimeout(searchTimer);
        
        if(term.length < 2) {
            resultsBox.hide().empty();
            return;
        }

        searchTimer = setTimeout(function() {
            // نمایش لودینگ
            resultsBox.show().html('<div style="padding:15px;text-align:center;color:#999;font-size:12px;">در حال جستجو...</div>');
            
            if (typeof reyhan_pm_ajax === 'undefined') {
                console.error('Reyhan Panel Error: Variables not localized.');
                return;
            }

            $.ajax({
                url: reyhan_pm_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'reyhan_search_users_ajax',
                    term: term,
                    security: reyhan_pm_ajax.search_nonce
                },
                success: function(response) {
                    if(response.success && response.data && response.data.length > 0) {
                        let html = '';
                        response.data.forEach(user => {
                            // جلوگیری از شکستن HTML با کوتیشن
                            const safeJson = JSON.stringify(user).replace(/'/g, "&#39;");
                            
                            html += `
                                <div class="rp-search-result-item" data-uid="${user.id}" data-json='${safeJson}'>
                                    <div class="rp-res-avatar"><img src="${user.avatar}" alt="user"></div>
                                    <div class="rp-res-info">
                                        <h4>${user.name}</h4>
                                        <span>${user.email} ${user.mobile ? ' | ' + user.mobile : ''}</span>
                                    </div>
                                </div>
                            `;
                        });
                        resultsBox.html(html);
                    } else {
                        resultsBox.html('<div style="padding:15px;text-align:center;color:#d63638;font-size:12px;">کاربری با این مشخصات یافت نشد.</div>');
                    }
                },
                error: function() {
                    resultsBox.html('<div style="padding:10px;text-align:center;color:red;">خطا در ارتباط.</div>');
                }
            });
        }, 600);
    });

    // کلیک روی نتیجه جستجو (انتخاب)
    $(document).on('click', '.rp-search-result-item', function() {
        const user = $(this).data('json');
        
        // پر کردن کارت
        $('#u-img').attr('src', user.avatar);
        $('#u-name').text(user.name);
        $('#u-email').text(user.email);
        $('#u-mobile').text(user.mobile || '---');
        
        // ذخیره ID
        hiddenInput.val(user.id);
        
        // تغییرات ظاهری (مخفی کردن اینپوت و نمایش کارت)
        $('#rp-search-label').text('کاربر انتخاب شده:').css('color', '#4caf50');
        searchWrapper.addClass('user-selected'); // این کلاس مهم است برای CSS جدید
        userCard.css('display', 'flex').hide().fadeIn(300); // انیمیشن نرم
        
        // پاکسازی
        resultsBox.hide().empty();
        searchInput.val('');
    });

    // دکمه تغییر کاربر
    $('#btn-change-user').on('click', function() {
        hiddenInput.val('');
        userCard.hide();
        searchWrapper.removeClass('user-selected'); // نمایش مجدد اینپوت
        
        $('#rp-search-label').text('گیرنده پیام').css('color', '');
        searchInput.focus();
    });

    // بستن نتایج با کلیک بیرون
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.rp-search-user-box').length) {
            resultsBox.hide();
        }
    });

    // ============================================================
    // ارسال فرم
    // ============================================================
    msgForm.on('submit', function(e) {
        e.preventDefault();
        const userId = hiddenInput.val();
        const title = $('#msg-title').val().trim();
        const content = $('#msg-content').val().trim();
        const sendEmail = $('#send_email_check').is(':checked');

        if (!userId) { alert('لطفاً ابتدا یک کاربر را جستجو و انتخاب کنید.'); return; }
        if (!title || !content) { alert('عنوان و متن پیام نمی‌تواند خالی باشد.'); return; }

        const btn = $(this).find('button[type="submit"]');
        const originalText = btn.html();
        
        // حالت لودینگ دکمه
        btn.prop('disabled', true).html('<span class="dashicons dashicons-update" style="animation:spin 1s infinite linear"></span> در حال ارسال...');

        $.ajax({
            url: reyhan_pm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'reyhan_send_personal_message',
                security: reyhan_pm_ajax.search_nonce,
                user_id: userId,
                title: title,
                content: content,
                send_email: sendEmail ? 'true' : 'false'
            },
            success: function(response) {
                if (response.success) {
                    // نمایش پیام موفقیت زیبا
                    let successBox = $('<div class="notice notice-success is-dismissible" style="margin: 10px 0; padding:10px;"><p>✅ پیام با موفقیت ارسال شد.</p></div>');
                    msgForm.before(successBox);
                    $('html, body').animate({ scrollTop: successBox.offset().top - 50 }, 500);
                    
                    setTimeout(() => {
                        successBox.fadeOut(() => successBox.remove());
                        resetFormComplete();
                    }, 2000);
                    
                } else {
                    // نمایش خطا
                    let errorMsg = response.data || 'خطایی رخ داد.';
                    let errorBox = $('<div class="notice notice-error is-dismissible" style="margin: 10px 0;"><p>'+errorMsg+'</p></div>');
                    msgForm.before(errorBox);
                    $('html, body').animate({ scrollTop: errorBox.offset().top - 50 }, 500);
                }
            },
            error: function() { 
                alert('خطای ارتباط با سرور. لطفاً مجدد تلاش کنید.'); 
            },
            complete: function() { 
                btn.prop('disabled', false).html(originalText); 
            }
        });
    });
});