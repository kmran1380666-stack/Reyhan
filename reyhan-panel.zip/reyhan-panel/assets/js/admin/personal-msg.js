jQuery(document).ready(function($) {

    // متغیرهای سراسری
    const searchInput = $('#rp-user-search-input');
    const resultsBox = $('#rp-user-search-results');
    const userCard = $('#rp-user-info-card');
    const hiddenInput = $('#selected_user_id');
    const msgForm = $('#rp-personal-msg-form');
    const modal = $('#rp-reset-confirm-modal');
    
    let searchTimer;

    // --- تابع ریست کامل ---
    function resetFormComplete() {
        // 1. خالی کردن فیلدها
        $('#msg-title').val('');
        $('#msg-content').val('');
        $('#send_email_check').prop('checked', false);
        hiddenInput.val('');
        
        // 2. ریست کردن جستجو
        searchInput.val('');
        userCard.hide();
        $('.rp-search-user-box').removeClass('user-selected');
        $('#rp-search-label').text('کاربر مورد نظر خود را جستجو کنید').css('color', '');
        
        // 3. بستن پاپ‌آپ (با حذف کلاس)
        modal.removeClass('active');

        // 4. فوکس (اسکرول به بالا)
        $('html, body').animate({ scrollTop: 0 }, 300);
        setTimeout(() => searchInput.focus(), 350);
    }

    // --- باز کردن پاپ‌آپ ---
    function showModal() {
        // به جای fadeIn از کلاس استفاده می‌کنیم تا Flex باقی بماند
        modal.addClass('active');
    }

    // ============================================================
    // هندلر دکمه "نوشتن پیام جدید"
    // ============================================================
    $(document).on('click', '#btn-new-msg', function(e) {
        e.preventDefault();
        
        // بررسی پر بودن فیلدها
        const hasUser    = (hiddenInput.val() || '').trim() !== '';
        const hasTitle   = ($('#msg-title').val() || '').trim() !== '';
        const hasContent = ($('#msg-content').val() || '').trim() !== '';

        if ( hasUser || hasTitle || hasContent ) {
            // اگر چیزی پر است، پاپ‌آپ را نشان بده
            if (modal.length > 0) {
                showModal();
            } else {
                alert('خطا: المان پاپ‌آپ در صفحه پیدا نشد.');
            }
        } else {
            // اگر همه چیز خالی است، ریست کن
            resetFormComplete();
        }
    });

    // --- دکمه‌های داخل پاپ‌آپ ---
    $(document).on('click', '#btn-modal-confirm', function() {
        resetFormComplete(); // کاربر تایید کرد -> همه چیز پاک شود
    });

    $(document).on('click', '#btn-modal-cancel', function() {
        modal.removeClass('active'); // انصراف
    });

    // بستن با کلیک روی فضای تاریک
    $(document).on('click', '#rp-reset-confirm-modal', function(e) {
        if ($(e.target).is('#rp-reset-confirm-modal')) {
            $(this).removeClass('active');
        }
    });

    // ============================================================
    // بخش‌های دیگر (جستجو و ارسال) - بدون تغییر
    // ============================================================
    
    searchInput.on('input', function() {
        let term = $(this).val().trim();
        clearTimeout(searchTimer);
        
        if(term.length < 2) {
            resultsBox.hide().empty();
            return;
        }

        searchTimer = setTimeout(function() {
            resultsBox.show().html('<div style="padding:15px;text-align:center;color:#999;">در حال جستجو...</div>');
            
            if (typeof reyhan_pm_ajax === 'undefined') return;

            $.ajax({
                url: reyhan_pm_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'reyhan_search_users_ajax',
                    term: term,
                    security: reyhan_pm_ajax.search_nonce
                },
                success: function(response) {
                    if(response.success && response.data.length > 0) {
                        let html = '';
                        response.data.forEach(user => {
                            html += `
                                <div class="rp-search-result-item" data-uid="${user.id}" data-json='${JSON.stringify(user)}'>
                                    <div class="rp-res-avatar"><img src="${user.avatar}" alt=""></div>
                                    <div class="rp-res-info">
                                        <h4>${user.name}</h4>
                                        <span>${user.email} ${user.mobile ? ' | ' + user.mobile : ''}</span>
                                    </div>
                                </div>
                            `;
                        });
                        resultsBox.html(html);
                    } else {
                        resultsBox.html('<div style="padding:15px;text-align:center;color:#d63638;">کاربری یافت نشد.</div>');
                    }
                }
            });
        }, 600);
    });

    $(document).on('click', '.rp-search-result-item', function() {
        const user = $(this).data('json');
        $('#u-img').attr('src', user.avatar);
        $('#u-name').text(user.name);
        $('#u-email').text(user.email);
        $('#u-mobile').text(user.mobile || '---');
        hiddenInput.val(user.id);
        $('#rp-search-label').text('کاربری که انتخاب کردید:').css('color', '#4caf50');
        $('.rp-search-user-box').addClass('user-selected');
        userCard.show();
        resultsBox.hide().empty();
        searchInput.val('');
    });

    $('#btn-change-user').on('click', function() {
        hiddenInput.val('');
        userCard.hide();
        $('.rp-search-user-box').removeClass('user-selected');
        searchInput.focus();
        $('#rp-search-label').text('کاربر مورد نظر خود را جستجو کنید').css('color', '');
    });

    $(document).on('click', function(e) {
        if (!$(e.target).closest('.rp-search-user-box').length) {
            resultsBox.hide();
        }
    });

    msgForm.on('submit', function(e) {
        e.preventDefault();
        const userId = hiddenInput.val();
        const title = $('#msg-title').val().trim();
        const content = $('#msg-content').val().trim();
        const sendEmail = $('#send_email_check').is(':checked');

        if (!userId) { alert('لطفاً ابتدا یک کاربر را انتخاب کنید.'); return; }
        if (!title || !content) { alert('عنوان و متن پیام نمی‌تواند خالی باشد.'); return; }

        const btn = $(this).find('button[type="submit"]');
        const originalText = btn.html();
        btn.prop('disabled', true).text('در حال ارسال...');

        $.ajax({
            url: reyhan_pm_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'reyhan_send_personal_message',
                security: reyhan_pm_ajax.search_nonce,
                user_id: userId,
                title: title,
                content: content,
                send_email: sendEmail ? 'true' : 'false'
            },
            success: function(response) {
                if (response.success) {
                    alert('پیام با موفقیت ارسال شد.');
                    resetFormComplete();
                } else {
                    if (response.data && response.data.indexOf('<') !== -1) {
                         let errorBox = $('<div class="notice notice-error is-dismissible" style="margin: 10px 0;"><p>'+response.data+'</p></div>');
                         msgForm.before(errorBox);
                         $('html, body').animate({ scrollTop: errorBox.offset().top - 50 }, 500);
                         setTimeout(() => errorBox.fadeOut(), 5000);
                    } else {
                        alert(response.data || 'خطایی رخ داد.');
                    }
                }
            },
            error: function() { alert('خطای ارتباط با سرور.'); },
            complete: function() { btn.prop('disabled', false).html(originalText); }
        });
    });
});