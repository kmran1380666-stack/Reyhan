jQuery(document).ready(function($) {
    $('.rp-do-export').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var type = $btn.data('type');
        var originalText = $btn.text();

        // Simple visual feedback
        $btn.text('در حال پردازش...').prop('disabled', true);

        var data = {
            action: 'reyhan_export_data_process', // This needs a PHP handler
            security: reyhan_export_ajax.nonce,
            export_type: type
        };

        // For actual file download, normally we redirect or open a window
        // But here we simulate an AJAX check first
        $.post(reyhan_export_ajax.ajax_url, data, function(response) {
            $btn.text(originalText).prop('disabled', false);
            
            if ( response.success && response.data.url ) {
                // Trigger download
                window.location.href = response.data.url;
            } else {
                alert('خطا در ساخت فایل خروجی: ' + (response.data || 'Unknown'));
            }
        }).fail(function() {
            $btn.text(originalText).prop('disabled', false);
            alert('Server Error');
        });
    });
});