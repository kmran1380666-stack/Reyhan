jQuery(document).ready(function ($) {
    "use strict";

    if ($('#ticket-list-container').length) {
        var ticketContainer = $('#ticket-list-container');
        var chatBox = $('#conversation-content');
        var infoBar = $('#ticket-info-bar');
        var currentTicketId = null;

        function loadAdminTickets(status) {
            $.post(LocalData.ajax_url, { action: 'reyhan_admin_load_tickets', security: LocalData.nonce, status: status || 'active' }, function (res) {
                if (res.success) ticketContainer.html(res.data);
            });
        }

        $('.rp-mod-filter-btn').click(function (e) {
            e.preventDefault();
            $('.rp-mod-filter-btn').removeClass('active');
            $(this).addClass('active');
            loadAdminTickets($(this).data('status'));
        });

        $(document).on('click', '.ticket-list-item', function () {
            $('.ticket-list-item').removeClass('selected'); 
            $(this).addClass('selected');
            currentTicketId = $(this).data('id');
            
            if ($(this).data('status') === 'closed') $('.rp-reply-area').slideUp(); 
            else $('.rp-reply-area').slideDown();

            chatBox.html('<div class="rp-loading-state">در حال بارگذاری...</div>');
            infoBar.hide().empty();
            $('#delete-ticket-btn').show().data('id', currentTicketId);

            $.post(LocalData.ajax_url, { action: 'reyhan_admin_load_conv', security: LocalData.nonce, ticket_id: currentTicketId }, function (res) {
                if (res.success) {
                    infoBar.html(res.data.info).fadeIn();
                    chatBox.html(res.data.chat);
                    setTimeout(() => chatBox.scrollTop(chatBox[0].scrollHeight), 100);
                }
            });
        });

        $('#send-reply-btn').click(function () {
            if (!currentTicketId) return;
            var msg = $('#reply-text').val();
            var file = $('#reply-file')[0].files[0];
            var isClose = $('#close-ticket-check').is(':checked');
            var btn = $(this);

            if (!msg && !file) { 
                window.rpShowToast('متن پیام یا فایل ضمیمه الزامی است.', 'error'); 
                return; 
            }
            
            btn.prop('disabled', true).text('ارسال...');

            var fd = new FormData();
            fd.append('action', 'reyhan_admin_reply'); 
            fd.append('security', LocalData.nonce); 
            fd.append('ticket_id', currentTicketId); 
            fd.append('message', msg); 
            fd.append('status', isClose ? 'closed' : 'answered'); 
            if (file) fd.append('reply_file', file);

            $.ajax({
                url: LocalData.ajax_url, 
                type: 'POST', 
                data: fd, 
                contentType: false, 
                processData: false,
                success: function (res) {
                    btn.prop('disabled', false).html('ارسال پاسخ <span class="dashicons dashicons-arrow-left-alt"></span>');
                    if (res.success) {
                        if (isClose) { 
                            $('.ticket-list-item[data-id="' + currentTicketId + '"]').fadeOut(); 
                            $('.rp-reply-area').slideUp(); 
                            chatBox.empty(); 
                            infoBar.hide(); 
                        } else { 
                            $('.ticket-list-item[data-id="' + currentTicketId + '"]').click(); 
                        }
                        $('#reply-text').val(''); 
                        $('#reply-file').val(''); 
                        $('#file-name-display').text('');
                        
                        // نمایش نوتیفیکیشن موفقیت
                        window.rpShowToast('پاسخ شما با موفقیت ارسال شد.', 'success');
                    } else {
                        // نمایش نوتیفیکیشن خطا
                        window.rpShowToast(res.data, 'error');
                    }
                }
            });
        });

        // جستجوی پاسخ‌های آماده
        $('#canned-search-input').on('keyup focus', function () {
            var term = $(this).val().toLowerCase(); 
            var box = $('#canned-results');
            if (term.length < 1) { box.hide(); return; }
            
            if (LocalData.canned_responses) {
                var hits = Object.values(LocalData.canned_responses).filter(r => (r.title || '').toLowerCase().includes(term) || (r.content || '').toLowerCase().includes(term));
                if (hits.length) { 
                    var html = ''; 
                    hits.forEach(r => { html += `<div class="rp-canned-item" data-content="${(r.content || '').replace(/"/g, '&quot;')}"><strong>${r.title}</strong><br><small>${(r.content || '').substring(0, 50)}...</small></div>`; }); 
                    box.html(html).show(); 
                } else box.hide();
            }
        });

        $(document).on('click', '.rp-canned-item', function () {
            var txt = $('#reply-text'); 
            txt.val(txt.val() + (txt.val() ? '\n' : '') + $(this).data('content')); 
            $('#canned-results').hide();
        });

        loadAdminTickets('active');
        setInterval(() => loadAdminTickets($('.rp-mod-filter-btn.active').data('status')), 30000);
    }

    // --- منطق حذف تیکت (اصلاح شده) ---
    $(document).on('click', '#delete-ticket-btn', function (e) {
        e.preventDefault();
        var ticketId = $(this).data('id');

        if (!ticketId) {
            window.rpShowToast('هیچ تیکتی انتخاب نشده است.', 'error');
            return;
        }

        if (!confirm('آیا مطمئن هستید که می‌خواهید این تیکت را برای همیشه حذف کنید؟\nاین عملیات غیرقابل بازگشت است.')) {
            return;
        }

        var $btn = $(this);
        var originalText = $btn.html();
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> در حال حذف...');

        $.post(LocalData.ajax_url, {
            action: 'reyhan_admin_delete_ticket',
            security: LocalData.nonce,
            ticket_id: ticketId
        }, function (res) {
            if (res.success) {
                $('#conversation-content').html('<div class="rp-empty-state">تیکت حذف شد.</div>');
                $('#ticket-info-bar').empty().hide();
                $('.rp-reply-area').slideUp();
                $btn.hide();

                var currentStatus = $('.rp-mod-filter-btn.active').data('status') || 'active';
                if (typeof loadAdminTickets === 'function') {
                    loadAdminTickets(currentStatus);
                } else {
                    location.reload();
                }
                
                // نمایش نوتیفیکیشن موفقیت
                window.rpShowToast('تیکت با موفقیت حذف شد.', 'success');
            } else {
                // نمایش نوتیفیکیشن خطا
                window.rpShowToast(res.data, 'error');
                $btn.prop('disabled', false).html(originalText);
            }
        }).fail(function () {
            window.rpShowToast('خطای ارتباط با سرور', 'error');
            $btn.prop('disabled', false).html(originalText);
        });
    });
});