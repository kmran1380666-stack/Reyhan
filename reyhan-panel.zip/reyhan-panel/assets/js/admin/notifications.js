jQuery(document).ready(function ($) {
    "use strict";

    var notifData = [];
    var editIndex = -1;
    var $notifJson = $('#rp_notif_data_json');

    // لود اولیه اطلاعات
    if ($('#rp-notif-grid').length > 0) {
        try { notifData = JSON.parse($('#rp-notif-initial-data').val() || '[]'); } catch (e) { notifData = []; }
        renderNotifGrid();
    }

    // تابع رندر کردن لیست (نمایش کارت‌ها)
    function renderNotifGrid() {
        var html = '';
        var container = $('#rp-notif-grid');
        var emptyState = $('#rp-empty-state');

        if (notifData.length === 0) {
            container.hide();
            emptyState.fadeIn();
        } else {
            emptyState.hide();
            container.css('display', 'flex'); // تغییر به Flex برای تمام عرض شدن
            
            $.each(notifData, function (i, item) {
                var title = item.title || '(بدون عنوان)';
                // نمایش متن به صورت خلاصه
                var msg = (item.msg || '').length > 100 ? (item.msg).substring(0, 100) + '...' : item.msg;
                
                // ساختار HTML کارت (تمام عرض)
                html += `
                <div class="rp-notif-card rp-card-${item.type || 'info'}">
                    <div class="rp-card-content-wrapper">
                        <div class="rp-card-header">
                            <span class="rp-card-title">${title}</span>
                            <span class="rp-card-date">#${i + 1}</span>
                        </div>
                        <div class="rp-card-msg">${msg}</div>
                    </div>
                    <div class="rp-card-actions">
                        <button type="button" class="rp-btn-sm edit-notif" data-index="${i}">
                            <span class="dashicons dashicons-edit"></span> ویرایش
                        </button>
                        <button type="button" class="rp-btn-sm delete-notif" data-index="${i}">
                            <span class="dashicons dashicons-trash"></span> حذف
                        </button>
                    </div>
                </div>`;
            });
            container.html(html);
        }
        // آپدیت کردن input مخفی برای ارسال به دیتابیس
        $notifJson.val(JSON.stringify(notifData));
    }

    // دکمه افزودن جدید
    $('#rp-btn-add-new').click(function (e) {
        e.preventDefault();
        editIndex = -1;
        $('#edit-title, #edit-msg').val('');
        $('#edit-type').val('info');
        $('#rp-editor-title').text('افزودن اطلاعیه جدید');
        $('#rp-editor-wrapper').slideDown();
        // اسکرول به فرم ویرایش
        $('html, body').animate({ scrollTop: $("#rp-editor-wrapper").offset().top - 100 }, 500);
    });

    // دکمه انصراف
    $('#rp-btn-cancel').click(function () {
        $('#rp-editor-wrapper').slideUp();
    });

    // دکمه ویرایش آیتم
    $(document).on('click', '.edit-notif', function (e) {
        e.preventDefault();
        editIndex = $(this).data('index');
        var item = notifData[editIndex];
        
        $('#edit-title').val(item.title);
        $('#edit-type').val(item.type);
        $('#edit-msg').val(item.msg);
        
        $('#rp-editor-title').text('ویرایش اطلاعیه');
        $('#rp-editor-wrapper').slideDown();
        $('html, body').animate({ scrollTop: $("#rp-editor-wrapper").offset().top - 100 }, 500);
    });

    // دکمه حذف آیتم
    $(document).on('click', '.delete-notif', function (e) {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید که می‌خواهید این اطلاعیه را حذف کنید؟')) {
            notifData.splice($(this).data('index'), 1);
            renderNotifGrid();
            window.rpShowToast('اطلاعیه حذف شد (برای اعمال نهایی ذخیره کنید)', 'warning');
        }
    });

    // --- دکمه ثبت (داخل فرم ویرایش) ---
    $('#rp-btn-save-item').click(function (e) {
        e.preventDefault();

        // دریافت مقادیر
        var title = $('#edit-title').val().trim();
        var msg = $('#edit-msg').val().trim();
        var type = $('#edit-type').val();

        // 1. اعتبارسنجی (جلوگیری از ثبت خالی)
        if (title === '' || msg === '') {
            window.rpShowToast('لطفاً عنوان و متن اطلاعیه را کامل کنید.', 'error');
            return; // توقف اجرا
        }

        var newItem = { 
            title: title, 
            type: type, 
            msg: msg, 
            active: '1',
            date: new Date().toLocaleDateString('fa-IR') // اختیاری: ثبت تاریخ
        };

        // 2. افزودن یا آپدیت در آرایه
        if (editIndex === -1) {
            // افزودن به ابتدای لیست (جدیدترین بالا)
            notifData.unshift(newItem); 
        } else {
            // ویرایش آیتم موجود
            notifData[editIndex] = newItem;
        }

        // 3. رندر مجدد و بستن فرم
        renderNotifGrid();
        $('#rp-editor-wrapper').slideUp();

        // 4. نمایش پیام موفقیت (موفقیت در افزودن به لیست)
        window.rpShowToast('اطلاعیه به لیست اضافه شد. برای انتشار نهایی دکمه «ذخیره تغییرات» را بزنید.', 'success');
    });
});