jQuery(document).ready(function ($) {
    "use strict";

    var notifData = [];
    var editIndex = -1;
    const $notifJson = $('#rp_notif_data_json');
    const ajaxNonce = $('#rp_admin_nonce').val();

    // ۱. لود دیتا با خطاگیری دقیق
    try {
        const rawData = $('#rp-notif-initial-data').val();
        notifData = JSON.parse(rawData || '[]');
    } catch (e) {
        notifData = [];
    }
    renderNotifGrid();

    function renderNotifGrid() {
        var html = '';
        if (notifData.length === 0) {
            $('#rp-notif-grid').hide();
            $('#rp-empty-state').fadeIn();
        } else {
            $('#rp-empty-state').hide();
            $('#rp-notif-grid').css('display', 'flex');
            
            $.each(notifData, function (i, item) {
                html += `
                <div class="rp-notif-card rp-card-${item.type || 'info'}">
                    <div class="rp-card-content-wrapper">
                        <div class="rp-card-header">
                            <span class="rp-card-title">${item.title}</span>
                        </div>
                        <div class="rp-card-msg">${item.msg}</div>
                    </div>
                    <div class="rp-card-actions">
                        <button type="button" class="rp-btn-sm edit-notif" data-index="${i}"><span class="dashicons dashicons-edit"></span></button>
                        <button type="button" class="rp-btn-sm delete-notif" data-index="${i}"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>`;
            });
            $('#rp-notif-grid').html(html);
        }
        $notifJson.val(JSON.stringify(notifData));
    }

    // ۲. متد ذخیره در دیتابیس (AJAX)
    function persistToDatabase() {
        $.post(ajaxurl, {
            action: 'rp_sync_notifications',
            nonce: ajaxNonce,
            notifications: JSON.stringify(notifData)
        });
    }

    $('#rp-btn-save-item').click(function (e) {
        e.preventDefault();
        var title = $('#edit-title').val().trim();
        var msg = $('#edit-msg').val().trim();

        if (!title || !msg) {
            if(window.rpShowToast) window.rpShowToast('فیلدها نباید خالی باشند', 'error');
            return;
        }

        var newItem = {
            id: editIndex === -1 ? 'n_' + Date.now() : notifData[editIndex].id,
            title: title,
            msg: msg,
            type: $('#edit-type').val(),
            date: new Date().toLocaleDateString('fa-IR')
        };

        if (editIndex === -1) {
            notifData.unshift(newItem); // اضافه کردن به ابتدای لیست (بدون حذف بقیه)
        } else {
            notifData[editIndex] = newItem; // ویرایش همان آیتم
        }

        renderNotifGrid();
        persistToDatabase(); // ذخیره آنی
        $('#rp-editor-wrapper').slideUp();
        if(window.rpShowToast) window.rpShowToast('لیست بروزرسانی شد', 'success');
        editIndex = -1; // ریست کردن ایندکس برای ثبت بعدی
    });

    $(document).on('click', '.edit-notif', function() {
        editIndex = $(this).data('index');
        var item = notifData[editIndex];
        $('#edit-title').val(item.title);
        $('#edit-msg').val(item.msg);
        $('#edit-type').val(item.type);
        $('#rp-editor-wrapper').slideDown();
    });

    $(document).on('click', '.delete-notif', function() {
        if(confirm('حذف شود؟')) {
            notifData.splice($(this).data('index'), 1);
            renderNotifGrid();
            persistToDatabase();
        }
    });

    $('#rp-btn-add-new').click(function() {
        editIndex = -1;
        $('#edit-title, #edit-msg').val('');
        $('#rp-editor-wrapper').slideDown();
    });
});