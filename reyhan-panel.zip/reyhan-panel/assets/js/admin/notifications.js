jQuery(document).ready(function ($) {
    "use strict";

    var notifData = [];
    var editIndex = -1;
    var $notifJson = $('#rp_notif_data_json');

    if ($('#rp-notif-grid').length > 0) {
        try { notifData = JSON.parse($('#rp-notif-initial-data').val() || '[]'); } catch (e) { notifData = []; }
        renderNotifGrid();
    }

    function renderNotifGrid() {
        var html = '';
        var container = $('#rp-notif-grid');
        var emptyState = $('#rp-empty-state');

        if (notifData.length === 0) {
            container.hide(); emptyState.fadeIn();
        } else {
            emptyState.hide(); container.css('display', 'grid');
            $.each(notifData, function (i, item) {
                var title = item.title || '(بدون عنوان)';
                var msg = (item.msg || '').substring(0, 80) + '...';
                html += `<div class="rp-notif-card rp-card-${item.type || 'info'}"><div class="rp-card-header"><span class="rp-card-title">${title}</span></div><div class="rp-card-msg">${msg}</div><div class="rp-card-actions"><button type="button" class="rp-btn-sm edit-notif" data-index="${i}">ویرایش</button><button type="button" class="rp-btn-sm delete-notif" data-index="${i}">حذف</button></div></div>`;
            });
            container.html(html);
        }
        $notifJson.val(JSON.stringify(notifData));
    }

    $('#rp-btn-add-new').click(function (e) {
        e.preventDefault(); editIndex = -1;
        $('#edit-title, #edit-msg').val(''); $('#edit-type').val('info');
        $('#rp-editor-title').text('افزودن اطلاعیه جدید');
        $('#rp-editor-wrapper').slideDown();
    });

    $('#rp-btn-cancel').click(function () { $('#rp-editor-wrapper').slideUp(); });

    $(document).on('click', '.edit-notif', function (e) {
        e.preventDefault(); editIndex = $(this).data('index');
        var item = notifData[editIndex];
        $('#edit-title').val(item.title); $('#edit-type').val(item.type); $('#edit-msg').val(item.msg);
        $('#rp-editor-title').text('ویرایش اطلاعیه');
        $('#rp-editor-wrapper').slideDown();
    });

    $(document).on('click', '.delete-notif', function (e) {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید؟')) {
            notifData.splice($(this).data('index'), 1); renderNotifGrid();
        }
    });

    $('#rp-btn-save-item').click(function (e) {
        e.preventDefault();
        var newItem = { title: $('#edit-title').val(), type: $('#edit-type').val(), msg: $('#edit-msg').val(), active: '1' };
        if (editIndex === -1) notifData.unshift(newItem); else notifData[editIndex] = newItem;
        renderNotifGrid();
        $('#rp-editor-wrapper').slideUp();
    });
});