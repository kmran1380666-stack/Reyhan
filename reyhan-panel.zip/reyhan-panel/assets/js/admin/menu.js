jQuery(document).ready(function ($) {
    "use strict";

    // لیست آیکون‌های استاندارد
    const dashicons = [
        'dashicons-dashboard', 'dashicons-admin-users', 'dashicons-cart', 'dashicons-tickets-alt',
        'dashicons-admin-home', 'dashicons-admin-settings', 'dashicons-email', 'dashicons-phone',
        'dashicons-products', 'dashicons-analytics', 'dashicons-awards', 'dashicons-store',
        'dashicons-wallet', 'dashicons-heart', 'dashicons-star-filled', 'dashicons-location',
        'dashicons-info', 'dashicons-warning', 'dashicons-businessman', 'dashicons-businesswoman',
        'dashicons-menu', 'dashicons-admin-site', 'dashicons-calendar-alt', 'dashicons-groups',
        'dashicons-format-chat', 'dashicons-video-alt3', 'dashicons-images-alt2', 'dashicons-welcome-learn-more',
        'dashicons-lock', 'dashicons-shield', 'dashicons-bell', 'dashicons-search'
    ];

    // جابجایی مودال‌ها به بادی
    var $modal = $('#rp-menu-modal');
    var $warnModal = $('#rp_save_warning_modal');
    if ($modal.length > 0 && $modal.parent().is('body') === false) $modal.appendTo('body');
    if ($warnModal.length > 0 && $warnModal.parent().is('body') === false) $warnModal.appendTo('body');

    var menuData = [];
    var initialDataStr = ""; // برای نگهداری وضعیت اولیه جهت مقایسه
    
    var $fixedContainer = $('#rp-fixed-items-container');
    var hasWoo = $fixedContainer.data('has-woo') == '1';

    var fixedDefs = [
        { action: 'dashboard', label: 'داشبورد', icon: 'dashicons-dashboard' },
        { action: 'profile', label: 'اطلاعات کاربری', icon: 'dashicons-admin-users' },
        { action: 'orders', label: 'سفارشات', icon: 'dashicons-cart', woo: true },
        { action: 'tickets', label: 'پشتیبانی', icon: 'dashicons-businesswoman' }
    ];

    // --- باز کردن مودال اصلی ---
    $(document).on('click', '#rp-open-menu-modal', function (e) {
        e.preventDefault();
        
        var raw = $('#rp_panel_menu_json').val();
        try { menuData = raw ? JSON.parse(raw) : []; } catch (e) { menuData = []; }

        renderMenu();
        
        // ذخیره وضعیت اولیه برای تشخیص تغییرات
        setTimeout(function(){
            initialDataStr = JSON.stringify(collectCurrentData());
        }, 200);

        $modal.css('display', 'flex');
        setTimeout(function() { $modal.addClass('rp-visible'); }, 50);
        $('body').css('overflow', 'hidden');
    });

    // --- تابع جمع‌آوری داده‌های فعلی از فرم ---
    function collectCurrentData() {
        var current = [];
        // جمع‌آوری ثابت‌ها
        $('#rp-fixed-items-container .rp-fixed-card').each(function () {
            current.push({
                type: 'fixed',
                action: $(this).data('action'),
                label: $(this).find('.rp-inp-label').val(),
                icon: $(this).find('.rp-icon-val').val()
            });
        });
        // جمع‌آوری دلخواه‌ها
        $('#rp-custom-items-container .rp-custom-item-row').each(function () {
            var l = $(this).find('.cust-label').val();
            if (l) {
                current.push({
                    type: 'custom',
                    action: 'custom_' + Math.floor(Math.random() * 999999), // اکشن رندوم مهم نیست، محتوا مهم است
                    label: l,
                    icon: $(this).find('.rp-icon-val').val(),
                    content_type: $(this).find('.cust-type').val(),
                    content_value: $(this).find('.cust-val').val()
                });
            }
        });
        return current;
    }

    // --- بررسی تغییرات و بستن ---
    function checkAndClose() {
        var currentData = collectCurrentData();
        // مقایسه رشته‌ای برای تشخیص تغییر
        // نکته: برای مقایسه دقیق، ویژگی action در آیتم‌های کاستوم را نادیده می‌گیریم چون رندوم است
        var currentStr = JSON.stringify(currentData, function(key, val) {
            if (key === 'action' && val.startsWith('custom_')) return undefined;
            return val;
        });
        var initStr = JSON.stringify(JSON.parse(initialDataStr || "[]"), function(key, val) {
            if (key === 'action' && val.startsWith('custom_')) return undefined;
            return val;
        });

        if (currentStr !== initStr) {
            // تغییرات وجود دارد -> نمایش هشدار
            $warnModal.fadeIn(200);
        } else {
            // تغییری نیست -> بستن مستقیم
            forceCloseModal();
        }
    }

    function forceCloseModal() {
        $modal.removeClass('rp-visible');
        setTimeout(function() {
            $modal.css('display', 'none');
            $('body').css('overflow', '');
        }, 400);
    }

    // دکمه‌های بستن و انصراف
    $(document).on('click', '.rp-modal-close', function(e) {
        e.preventDefault();
        checkAndClose();
    });
    
    // دکمه‌های داخل پاپ‌آپ هشدار
    $(document).on('click', '#rp-warn-no-save', function() {
        $warnModal.fadeOut(200);
        forceCloseModal(); // بستن بدون ذخیره
    });

    $(document).on('click', '#rp-warn-do-save', function() {
        $warnModal.fadeOut(200);
        saveMenuViaAjax(); // ذخیره و سپس بستن
    });

    // --- ذخیره نهایی (AJAX) ---
    $(document).on('click', '#rp-save-menu-changes', function () {
        saveMenuViaAjax();
    });

    function saveMenuViaAjax() {
        var finalData = collectCurrentData();
        var jsonStr = JSON.stringify(finalData);
        var $btn = $('#rp-save-menu-changes');
        var originalText = $btn.html();

        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> در حال ذخیره...');

        $.ajax({
            url: reyhan_admin_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'reyhan_save_menu_structure',
                security: reyhan_admin_ajax.nonce,
                menu_data: jsonStr
            },
            success: function(res) {
                if(res.success) {
                    // بروزرسانی فیلد مخفی (جهت اطمینان)
                    $('#rp_panel_menu_json').val(jsonStr);
                    
                    // آپدیت وضعیت اولیه (که دیگر به عنوان تغییر جدید شناخته نشود)
                    initialDataStr = JSON.stringify(finalData);

                    // نمایش نوتیفیکیشن موفقیت
                    showToastNotification(res.data, 'success');
                    
                    // بستن مودال
                    forceCloseModal();
                } else {
                    alert(res.data);
                }
            },
            error: function() {
                alert('خطا در برقراری ارتباط با سرور.');
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
            }
        });
    }

    // تابع نمایش تست (Toast)
    function showToastNotification(msg, type) {
        var $toast = $('<div class="rp-notification-toast rp-toast-'+type+'">'+msg+'</div>');
        $('body').append($toast);
        $toast.css({
            'position': 'fixed', 'bottom': '30px', 'left': '30px', 'z-index': '9999999',
            'background': '#333', 'color': '#fff', 'padding': '15px 25px', 'border-radius': '10px',
            'box-shadow': '0 10px 30px rgba(0,0,0,0.2)', 'opacity': '0', 'transform': 'translateY(20px)',
            'transition': '0.3s'
        });
        if(type === 'success') $toast.css({'background': '#10b981'});
        
        setTimeout(function(){ $toast.css({'opacity': '1', 'transform': 'translateY(0)'}); }, 10);
        setTimeout(function(){ 
            $toast.css({'opacity': '0', 'transform': 'translateY(20px)'});
            setTimeout(function(){ $toast.remove(); }, 300);
        }, 3000);
    }

    // --- توابع رندرینگ و کامپوننت‌ها (بدون تغییر منطق، فقط کپی شده) ---
    function buildIconPicker(currentIcon) {
        let gridHtml = '';
        dashicons.forEach(icon => {
            let active = (icon === currentIcon) ? 'selected' : '';
            gridHtml += `<div class="rp-icon-option ${active}" data-icon="${icon}" title="${icon}"><span class="dashicons ${icon}"></span></div>`;
        });
        return `
        <div class="rp-icon-picker-wrapper">
            <input type="hidden" class="rp-icon-val" value="${currentIcon}">
            <div class="rp-icon-trigger" title="تغییر آیکون">
                <div class="rp-trigger-preview"><span class="dashicons ${currentIcon}"></span></div>
            </div>
            <div class="rp-icon-dropdown-box">${gridHtml}</div>
        </div>`;
    }

    function renderMenu() {
        var $fixed = $('#rp-fixed-items-container').empty();
        var $custom = $('#rp-custom-items-container').empty();

        fixedDefs.forEach(function (def) {
            if (def.woo && !hasWoo) return;
            var current = menuData.find(i => i.action === def.action) || {};
            var lbl = current.label || def.label;
            var ico = current.icon || def.icon;

            var html = `
            <div class="rp-fixed-card" data-action="${def.action}">
                <div class="rp-fixed-icon-side">
                    <span class="rp-lbl-tiny">آیکون</span>
                    ${buildIconPicker(ico)}
                </div>
                <div class="rp-fixed-inputs">
                    <span class="rp-lbl-tiny">عنوان نمایشی</span>
                    <input type="text" class="rp-modern-input rp-inp-label" value="${lbl}">
                </div>
            </div>`;
            $fixed.append(html);
        });

        var customs = menuData.filter(i => i.type === 'custom');
        customs.forEach(item => addCustomRow(item));
    }

    $(document).on('click', '#rp-add-custom-item', function () {
        addCustomRow({ label: '', icon: 'dashicons-star-filled', content_type: 'shortcode', content_value: '' });
        var container = document.querySelector('.rp-modal-body');
        if(container) setTimeout(() => container.scrollTop = container.scrollHeight, 100);
    });

    function addCustomRow(data) {
        var type = data.content_type || 'shortcode';
        var val = data.content_value || '';
        var fieldHtml = getDynamicFieldHtml(type, val);

        var html = `
        <div class="rp-custom-item-row">
            <div class="rp-del-custom rp-del-row" title="حذف"><span class="dashicons dashicons-trash"></span></div>
            <div class="rp-custom-grid">
                <div><span class="rp-lbl-tiny">عنوان آیتم</span><input type="text" class="rp-modern-input cust-label" value="${data.label || ''}"></div>
                <div style="z-index: 20;"><span class="rp-lbl-tiny">آیکون</span>${buildIconPicker(data.icon || 'dashicons-star-filled')}</div>
                <div>
                    <span class="rp-lbl-tiny">نوع لینک</span>
                    <select class="rp-modern-select cust-type">
                        <option value="shortcode" ${type === 'shortcode' ? 'selected' : ''}>شورت‌کد</option>
                        <option value="elementor" ${type === 'elementor' ? 'selected' : ''}>المنتور</option>
                        <option value="link" ${type === 'link' ? 'selected' : ''}>لینک مستقیم</option>
                    </select>
                </div>
                <div class="rp-dynamic-field-wrap">
                    <span class="rp-lbl-tiny">مقدار / لینک / ID</span>
                    <div class="rp-dynamic-content">${fieldHtml}</div>
                </div>
            </div>
        </div>`;
        $('#rp-custom-items-container').append(html);
    }

    $(document).on('change', '.cust-type', function() {
        var type = $(this).val();
        var $container = $(this).closest('.rp-custom-grid').find('.rp-dynamic-content');
        var oldVal = $container.find('input').val() || '';
        $container.html(getDynamicFieldHtml(type, oldVal));
    });

    function getDynamicFieldHtml(type, value) {
        if(type === 'shortcode') return `<input type="text" class="rp-modern-input cust-val" value="${value}" placeholder="مثال: [my_shortcode]" dir="ltr">`;
        if(type === 'elementor') return `<input type="text" class="rp-modern-input cust-val" value="${value}" placeholder="شناسه قالب (مثال: 1540)" dir="ltr" style="text-align:center;">`;
        if(type === 'link') return `<input type="text" class="rp-modern-input cust-val" value="${value}" placeholder="https://example.com" dir="ltr">`;
        return '';
    }

    // دراپ‌داون آیکون
    $(document).on('click', '.rp-icon-trigger', function(e) {
        e.stopPropagation();
        $('.rp-icon-dropdown-box').not($(this).next()).removeClass('active');
        $(this).next('.rp-icon-dropdown-box').toggleClass('active');
    });

    $(document).on('click', '.rp-icon-option', function(e) {
        e.stopPropagation();
        var icon = $(this).data('icon');
        var $wrapper = $(this).closest('.rp-icon-picker-wrapper');
        $wrapper.find('.rp-icon-val').val(icon);
        $wrapper.find('.rp-trigger-preview span').attr('class', 'dashicons ' + icon);
        $wrapper.find('.rp-icon-dropdown-box').removeClass('active');
        $(this).siblings().removeClass('selected');
        $(this).addClass('selected');
    });

    $(document).on('click', function() { $('.rp-icon-dropdown-box').removeClass('active'); });

    // حذف سطر
    $(document).on('click', '.rp-del-row', function (e) {
        e.preventDefault(); e.stopPropagation();
        var $row = $(this).closest('.rp-custom-item-row');
        if (confirm('آیا از حذف این آیتم اطمینان دارید؟')) {
            $row.fadeOut(300, function(){ $(this).remove(); });
        }
    });

});