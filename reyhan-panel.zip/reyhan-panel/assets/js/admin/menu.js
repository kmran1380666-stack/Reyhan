jQuery(document).ready(function ($) {
    "use strict";

    // 1. انتقال قطعی مودال به انتهای body برای رفع مشکل z-index
    var $modal = $('#rp-menu-modal');
    if ($modal.length > 0 && $modal.parent().is('body') === false) {
        $modal.appendTo('body');
    }

    var menuData = [];

    // دریافت وضعیت ووکامرس از ویژگی دیتا
    var $fixedContainer = $('#rp-fixed-items-container');
    var hasWoo = $fixedContainer.data('has-woo') == '1';

    // تعریف آیتم‌های ثابت
    var fixedDefs = [
        { action: 'dashboard', label: 'داشبورد', icon: 'dashicons-dashboard' },
        { action: 'profile', label: 'اطلاعات کاربری', icon: 'dashicons-admin-users' },
        { action: 'orders', label: 'سفارشات', icon: 'dashicons-cart', woo: true },
        { action: 'tickets', label: 'پشتیبانی', icon: 'dashicons-businesswoman' }
    ];

    // --- باز کردن مودال ---
    $(document).on('click', '#rp-open-menu-modal', function (e) {
        e.preventDefault();

        var raw = $('#rp_panel_menu_json').val();
        try {
            menuData = raw ? JSON.parse(raw) : [];
        } catch (e) {
            console.error('RP Menu: JSON Error', e);
            menuData = [];
        }

        renderMenu();

        // نمایش با فلکس (مهم)
        $('#rp-menu-modal').css('display', 'flex').hide().fadeIn(200);
        $('body').css('overflow', 'hidden'); // قفل اسکرول
    });

    // --- بستن مودال ---
    $(document).on('click', '.rp-modal-close', function () {
        $('#rp-menu-modal').fadeOut(200);
        $('body').css('overflow', '');
    });

    // --- رندر کردن منو ---
    function renderMenu() {
        var $fixed = $('#rp-fixed-items-container').empty();
        var $custom = $('#rp-custom-items-container').empty();

        // 1. ثابت‌ها
        fixedDefs.forEach(function (def) {
            if (def.woo && !hasWoo) return;

            var current = menuData.find(function (i) { return i.action === def.action }) || {};
            var lbl = current.label || def.label;
            var ico = current.icon || def.icon;

            var html = `
            <div class="rp-menu-card" data-action="${def.action}">
                <div class="rp-card-header-row">
                    <span class="dashicons ${ico}" style="color:#2271b1; font-size:22px; width:22px; height:22px;"></span> 
                    <strong style="font-size:14px; color:#333;">${def.label}</strong>
                </div>
                <div class="rp-inp-grid">
                    <input type="text" class="rp-inp-label" value="${lbl}" placeholder="عنوان نمایشی" style="width:100%; border:1px solid #ddd; border-radius:4px; padding:6px;">
                    <input type="text" class="rp-inp-icon" value="${ico}" placeholder="کلاس آیکون" style="width:100%; direction:ltr; text-align:left; border:1px solid #ddd; border-radius:4px; padding:6px;">
                </div>
            </div>`;
            $fixed.append(html);
        });

        // 2. دلخواه‌ها
        var customs = menuData.filter(function (i) { return i.type === 'custom' });
        customs.forEach(function (item) { addCustomRow(item); });
    }

    // --- افزودن سطر دلخواه ---
    $(document).on('click', '#rp-add-custom-item', function () {
        addCustomRow({ label: '', icon: 'dashicons-admin-links', content_value: '' });
    });

    function addCustomRow(data) {
        var html = `
        <div class="rp-custom-row">
            <span class="dashicons dashicons-trash rp-del-row" title="حذف"></span>
            <div style="margin-bottom:10px; font-weight:bold; color:#46b450;">آیتم دلخواه</div>
            <input type="text" class="cust-label" value="${data.label || ''}" placeholder="عنوان آیتم" style="width:100%; margin-bottom:8px; border:1px solid #ddd; border-radius:4px; padding:6px;">
            <input type="text" class="cust-val" value="${data.content_value || ''}" placeholder="لینک (https://...) یا شورت‌کد" style="width:100%; margin-bottom:8px; direction:ltr; text-align:left; border:1px solid #ddd; border-radius:4px; padding:6px;">
            <input type="text" class="cust-icon" value="${data.icon || 'dashicons-admin-links'}" placeholder="آیکون (dashicons-...)" style="width:100%; direction:ltr; text-align:left; border:1px solid #ddd; border-radius:4px; padding:6px;">
        </div>`;
        $('#rp-custom-items-container').append(html);
    }

    // --- حذف سطر ---
    $(document).on('click', '.rp-del-row', function () {
        if (confirm('آیا مطمئن هستید؟')) $(this).closest('.rp-custom-row').remove();
    });

    // --- ذخیره نهایی ---
    $(document).on('click', '#rp-save-menu-changes', function () {
        var final = [];

        // جمع‌آوری ثابت‌ها
        $('#rp-fixed-items-container .rp-menu-card').each(function () {
            final.push({
                type: 'fixed',
                action: $(this).data('action'),
                label: $(this).find('.rp-inp-label').val(),
                icon: $(this).find('.rp-inp-icon').val()
            });
        });

        // جمع‌آوری دلخواه‌ها
        $('#rp-custom-items-container .rp-custom-row').each(function () {
            var l = $(this).find('.cust-label').val();
            if (l) {
                final.push({
                    type: 'custom',
                    action: 'custom_' + Math.floor(Math.random() * 99999),
                    label: l,
                    icon: $(this).find('.cust-icon').val(),
                    content_value: $(this).find('.cust-val').val()
                });
            }
        });

        $('#rp_panel_menu_json').val(JSON.stringify(final));
        $('#rp-menu-modal').fadeOut(200);
        $('body').css('overflow', '');
        alert('تنظیمات منو اعمال شد. لطفا برای ذخیره نهایی، دکمه "ذخیره تغییرات" پایین صفحه را بزنید.');
    });

});