<?php
namespace ReyhanPanel\Ajax;

class PersonalMessageHandler {

    public function __construct() {
        // اتصال درخواست‌های AJAX به متدها
        add_action('wp_ajax_reyhan_search_users_ajax', [ $this, 'handle_user_search' ]);
        add_action('wp_ajax_reyhan_send_personal_message', [ $this, 'handle_send_message' ]);
    }

    /**
     * جستجوی کاربر (AJAX)
     */
    public function handle_user_search() {
        // 1. بررسی امنیت
        check_ajax_referer('rp_personal_msg_nonce', 'security');

        // 2. دریافت ورودی
        $term = sanitize_text_field( $_POST['term'] ?? '' );
        
        if ( empty($term) || strlen($term) < 2 ) {
            wp_send_json_error('عبارت جستجو کوتاه است.');
        }

        // 3. کوئری جستجو (نام، ایمیل، نام کاربری)
        $args = [
            'search'         => '*' . $term . '*',
            'search_columns' => ['user_login', 'user_email', 'display_name'],
            'number'         => 10,
            'fields'         => 'all_with_meta', // برای دسترسی به متا دیتا
        ];

        // افزودن جستجو در شماره موبایل (Meta Query)
        $args['meta_query'] = [
            'relation' => 'OR',
            [
                'key'     => 'mobile',
                'value'   => $term,
                'compare' => 'LIKE'
            ],
            [
                'key'     => 'billing_phone',
                'value'   => $term,
                'compare' => 'LIKE'
            ]
        ];

        $user_query = new \WP_User_Query( $args );
        $users = $user_query->get_results();
        $results = [];

        foreach ( $users as $user ) {
            // دریافت موبایل
            $mobile = get_user_meta($user->ID, 'mobile', true);
            if(empty($mobile)) $mobile = get_user_meta($user->ID, 'billing_phone', true);

            $results[] = [
                'id'     => $user->ID,
                'name'   => $user->display_name,
                'email'  => $user->user_email,
                'mobile' => $mobile ? $mobile : '',
                'avatar' => get_avatar_url($user->ID),
            ];
        }

        wp_send_json_success( $results );
    }

    /**
     * ارسال پیام (AJAX) - (این قسمت بعدا تکمیل می‌شود اگر لازم بود)
     */
    public function handle_send_message() {
        // کدهای ارسال پیام...
        wp_send_json_success('پیام دریافت شد');
    }
}