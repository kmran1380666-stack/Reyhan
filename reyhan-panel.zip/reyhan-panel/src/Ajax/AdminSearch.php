<?php

add_action('wp_ajax_reyhan_search_users_ajax', function() {
    check_ajax_referer('reyhan_search_users', 'security');
    
    if(!current_user_can('read')) wp_send_json_error();

    $term = sanitize_text_field($_POST['term']);
    
    // جستجو در کاربران
    $query_args = [
        'search'         => '*' . $term . '*',
        'search_columns' => ['user_login', 'user_email', 'user_nicename', 'display_name'],
        'number'         => 10,
    ];
    
    // جستجوی متای موبایل (اختیاری - اگر افزونه فیلد موبایل دارد)
    $meta_query = [
        'relation' => 'OR',
        [
            'key'     => 'mobile', // کلید متای موبایل شما
            'value'   => $term,
            'compare' => 'LIKE'
        ]
    ];
    
    // ترکیب جستجوها (وردپرس استاندارد اجازه جستجوی ترکیبی متا و اصلی راحت را نمیدهد،
    // برای سادگی فعلا همان سرچ استاندارد را استفاده می‌کنیم)
    $users = get_users($query_args);
    
    $results = [];
    foreach($users as $user) {
        $results[] = [
            'id' => $user->ID,
            'name' => $user->display_name,
            'email' => $user->user_email,
            'mobile' => get_user_meta($user->ID, 'mobile', true), // فرض بر وجود متای mobile
            'avatar' => get_avatar_url($user->ID)
        ];
    }
    
    wp_send_json_success($results);
});