<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class UserTicket {

    public function __construct() {
        // هوک‌های تیکت
        add_action( 'wp_ajax_reyhan_user_list_tickets',   [ $this, 'handle_list' ] );
        add_action( 'wp_ajax_reyhan_user_view_ticket',    [ $this, 'handle_view' ] );
        add_action( 'wp_ajax_reyhan_user_create_ticket',  [ $this, 'handle_submit' ] );
        add_action( 'wp_ajax_reyhan_user_reply_ticket',   [ $this, 'handle_reply' ] );
        add_action( 'wp_ajax_reyhan_user_close',          [ $this, 'handle_close' ] );

        // هوک‌های سفارشات
        add_action( 'wp_ajax_reyhan_user_list_orders',    [ $this, 'handle_list_orders' ] );
        add_action( 'wp_ajax_reyhan_user_view_order',     [ $this, 'handle_view_order' ] );
    }

    /**
     * بررسی امنیت بدون قطع کردن (Die)
     */
    private function check_auth() {
        if ( ! isset( $_POST['security'] ) || ! wp_verify_nonce( $_POST['security'], 'reyhan_auth_nonce' ) ) {
            wp_send_json_error( 'نشست امنیتی منقضی شده. رفرش کنید.' );
            exit;
        }
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( 'لطفاً وارد شوید.' );
            exit;
        }
    }

    private function process_attachments_array( $files_array ) {
        $uploaded_ids = [];
        
        // چک کردن ساختار آرایه فایل
        if ( empty($files_array['name']) || !is_array($files_array['name']) ) return [];

        $count = count($files_array['name']);
        if ($count > 5) return new \WP_Error('err', 'تعداد فایل‌ها بیش از حد مجاز (۵ عدد) است.');

        // حلقه روی فایل‌ها
        for ( $i = 0; $i < $count; $i++ ) {
            if ( empty($files_array['name'][$i]) ) continue;

            // ساختن آرایه تکی برای تابع آپلود
            $file = [
                'name'     => $files_array['name'][$i],
                'type'     => $files_array['type'][$i],
                'tmp_name' => $files_array['tmp_name'][$i],
                'error'    => $files_array['error'][$i],
                'size'     => $files_array['size'][$i]
            ];

            $upload_res = $this->handle_secure_upload( $file );
            
            if ( is_wp_error($upload_res) ) {
                return $upload_res; // بازگشت خطا (اولین خطا)
            }
            $uploaded_ids[] = $upload_res;
        }
        return $uploaded_ids;
    }

    // --- لیست تیکت‌ها ---
    public function handle_list() {
        $this->check_auth();
        
        $uid = get_current_user_id();
        $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;
        
        $args = [
            'post_type'      => 'ticket',
            'posts_per_page' => 10,
            'paged'          => $paged,
            'author'         => $uid,
            'post_status'    => 'any', 
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];
        
        $query = new \WP_Query( $args );
        $tickets = $query->posts;

        ob_start();
        // مسیر فایل ویو
        $template = REYHAN_DIR . 'templates/frontend/view-tickets-list.php';
        if ( file_exists( $template ) ) {
            include $template;
        } else {
            echo '<div class="rp-error">قالب لیست تیکت یافت نشد.</div>';
        }
        $html = ob_get_clean();
        
        wp_send_json_success( ['html' => $html] );
    }

    // --- ثبت تیکت جدید ---
    public function handle_submit() {
        $this->check_auth();
        $uid = get_current_user_id();
        
        if ( get_transient( 'rp_flood_' . $uid ) ) { wp_send_json_error( 'لطفاً ۱ دقیقه صبر کنید.' ); exit; }

        $title = isset($_POST['title']) ? trim(sanitize_text_field($_POST['title'])) : '';
        $msg = isset($_POST['message']) ? trim(sanitize_textarea_field($_POST['message'])) : '';
        $dept = isset($_POST['department']) ? sanitize_text_field($_POST['department']) : 'general';
        $prio = isset($_POST['priority']) ? sanitize_text_field($_POST['priority']) : 'medium';

        if ( empty($title) ) wp_send_json_error( 'موضوع الزامی است.' );
        if ( is_numeric($title) ) wp_send_json_error( 'موضوع نمی‌تواند فقط عدد باشد.' );
        if ( mb_strlen($msg) < 5 ) wp_send_json_error( 'متن تیکت کوتاه است.' );

        // 1. آپلود فایل‌ها
        $att_ids = [];
        if ( ! empty( $_FILES['attachments'] ) ) {
            $res = $this->process_attachments_array( $_FILES['attachments'] );
            if ( is_wp_error($res) ) {
                wp_send_json_error( $res->get_error_message() );
                exit;
            }
            $att_ids = $res;
        }

        // 2. ایجاد پست
        $pid = wp_insert_post([
            'post_title' => $title, 'post_content' => wp_kses_post($msg),
            'post_status' => 'publish', 'post_type' => 'ticket', 'post_author' => $uid
        ]);

        if ( is_wp_error( $pid ) ) wp_send_json_error( 'خطا در ثبت تیکت.' );

        // 3. ذخیره متادیتا
        update_post_meta( $pid, '_ticket_department', $dept );
        update_post_meta( $pid, '_ticket_priority', $prio );
        update_post_meta( $pid, '_ticket_status', 'open' );
        update_post_meta( $pid, '_ticket_code', 'T-' . strtoupper(substr(md5($pid . time()), 0, 6)) );
        
        // ذخیره فایل‌ها (چند رکورد)
        if ( ! empty($att_ids) ) {
            foreach ( $att_ids as $att_id ) {
                add_post_meta( $pid, '_ticket_attachment_id', $att_id );
            }
        }

        set_transient( 'rp_flood_' . $uid, true, 60 );
        wp_send_json_success( 'تیکت با موفقیت ثبت شد.' );
    }

    // --- مشاهده تیکت ---
    public function handle_view() {
        $this->check_auth();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $post = get_post( $tid );
        
        if ( ! $post || $post->post_author != get_current_user_id() ) wp_send_json_error( 'تیکت نامعتبر.' );

        ob_start();
        include REYHAN_DIR . 'templates/frontend/view-single-ticket.php';
        wp_send_json_success( ob_get_clean() );
    }

    // --- پاسخ تیکت ---
    public function handle_reply() {
        $this->check_auth();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $msg = trim( sanitize_textarea_field( $_POST['message'] ?? '' ) );
        
        if(!$tid) wp_send_json_error('تیکت نامعتبر است.');
        if(empty($msg)) wp_send_json_error('متن پاسخ خالی است.');
        if(mb_strlen($msg) < 20) wp_send_json_error('متن پاسخ باید حداقل ۲۰ کاراکتر باشد.');

        $post = get_post($tid);
        if(!$post || $post->post_author != get_current_user_id()) wp_send_json_error('دسترسی ندارید.');

        // 1. آپلود فایل‌ها
        $att_ids = [];
        if ( ! empty( $_FILES['attachments'] ) ) {
            $res = $this->process_attachments_array( $_FILES['attachments'] );
            if ( is_wp_error($res) ) { wp_send_json_error( $res->get_error_message() ); exit; }
            $att_ids = $res;
        }

        // 2. ثبت کامنت
        $cid = wp_insert_comment([
            'comment_post_ID' => $tid, 'comment_content' => wp_kses_post($msg),
            'user_id' => get_current_user_id(), 'comment_type' => 'ticket_reply', 'comment_approved' => 1
        ]);

        if($cid) {
            if(!empty($att_ids)) {
                foreach($att_ids as $aid) {
                    add_comment_meta($cid, '_attachment_id', $aid);
                }
            }
            update_post_meta($tid, '_ticket_status', 'user_reply');
            update_post_meta($tid, '_ticket_updated', current_time('mysql'));
            wp_send_json_success('پاسخ ارسال شد.');
        }
        wp_send_json_error('خطا در ارسال پاسخ.');
    }

    // --- بستن تیکت ---
    public function handle_close() {
        $this->check_auth();
        $tid = intval($_POST['ticket_id']);
        $p = get_post($tid);
        if($p && $p->post_author == get_current_user_id()) {
            update_post_meta($tid, '_ticket_status', 'closed');
            wp_send_json_success('بسته شد.');
        }
        wp_send_json_error('خطا');
    }

    // --- سفارشات ---
    public function handle_list_orders() {
        $this->check_auth();
        if(!class_exists('WooCommerce')) wp_send_json_error('ووکامرس نیست');
        $orders = wc_get_orders(['customer_id'=>get_current_user_id(), 'limit'=>-1]);
        ob_start();
        include REYHAN_DIR . 'templates/frontend/view-orders-list.php';
        wp_send_json_success(ob_get_clean());
    }

    public function handle_view_order() {
        $this->check_auth();
        $order = wc_get_order(intval($_POST['order_id']));
        if(!$order || $order->get_user_id() != get_current_user_id()) wp_send_json_error('خطا');
        ob_start();
        include REYHAN_DIR . 'templates/frontend/view-order-details.php';
        wp_send_json_success(ob_get_clean());
    }

    private function handle_secure_upload( $file ) {
        if ( empty($file['name']) ) return false;
        $opts = get_option('reyhan_options');
        
        // 1. حجم
        $max_mb = !empty($opts['file_max_size']) ? floatval($opts['file_max_size']) : 2;
        if ( $file['size'] > $max_mb * 1024 * 1024 ) return new \WP_Error('err', "حجم فایل بیش از حد مجاز ($max_mb مگابایت) است.");

        // 2. فرمت و امنیت
        $ext = strtolower( pathinfo($file['name'], PATHINFO_EXTENSION) );
        $blocked = ['php','exe','bat','sh','js','svg','htaccess','ini','config','phtml'];
        if ( in_array( $ext, $blocked ) ) return new \WP_Error('err', 'آپلود این نوع فایل به دلایل امنیتی ممنوع است.');

        $allowed_str = !empty($opts['file_allowed_extensions']) ? $opts['file_allowed_extensions'] : 'jpg,png,pdf';
        $allowed = explode(',', strtolower($allowed_str));
        $allowed = array_map('trim', $allowed);
        if ( ! in_array( $ext, $allowed ) ) return new \WP_Error('err', 'فرمت فایل مجاز نیست.');

        // 3. آپلود با wp_handle_upload
        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
        }

        $upload_overrides = [ 'test_form' => false ];
        // نکته: wp_handle_upload فایل را جابجا می‌کند اما در مدیا ثبت نمی‌کند
        $movefile = wp_handle_upload( $file, $upload_overrides );

        if ( $movefile && ! isset( $movefile['error'] ) ) {
            // ثبت در کتابخانه مدیا (Attachment)
            $wp_filetype = wp_check_filetype( basename( $movefile['file'] ), null );
            $attachment = [
                'post_mime_type' => $wp_filetype['type'],
                'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $movefile['file'] ) ),
                'post_content'   => '',
                'post_status'    => 'inherit'
            ];
            $attach_id = wp_insert_attachment( $attachment, $movefile['file'] );
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $attach_data = wp_generate_attachment_metadata( $attach_id, $movefile['file'] );
            wp_update_attachment_metadata( $attach_id, $attach_data );
            
            return $attach_id;
        } else {
            return new \WP_Error( 'err', isset($movefile['error']) ? $movefile['error'] : 'خطا در آپلود.' );
        }
    }
}