<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Init {
    public function __construct() {
        // کلاس‌های قبلی شما اینجا هستند
        new AdminTicket();
        new AdminSearch();
        new UserTicket();
        
        // --- این خط را اضافه کنید ---
        new ExportHandler(); 
    }
}