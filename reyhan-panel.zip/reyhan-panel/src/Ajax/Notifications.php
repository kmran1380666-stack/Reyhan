<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Notifications {
    public function __construct() {
        add_action( 'wp_ajax_rp_sync_notifications', [ $this, 'handle_sync' ] );
    }

    public function handle_sync() {
        // امنیت
        if ( ! check_ajax_referer( 'rp_admin_nonce', 'nonce', false ) ) {
            wp_send_json_error();
        }

        $items = isset($_POST['notifications']) ? json_decode(stripslashes($_POST['notifications']), true) : [];

        if ( ! is_array($items) ) {
            wp_send_json_error();
        }

        // پاکسازی
        $clean_data = [];
        foreach ( $items as $item ) {
            $clean_data[] = [
                'id'    => sanitize_key($item['id']),
                'title' => sanitize_text_field($item['title']),
                'msg'   => sanitize_textarea_field($item['msg']),
                'type'  => sanitize_key($item['type']),
                'date'  => sanitize_text_field($item['date'])
            ];
        }

        $json = json_encode($clean_data, JSON_UNESCAPED_UNICODE);

        // بروزرسانی در آپشن اصلی ریحان
        $options = get_option('reyhan_options', []);
        $options['global_notifications_json'] = $json;
        update_option('reyhan_options', $options);

        // بروزرسانی برای سیستم Heavy (اگر استفاده میکنید)
        update_option('reyhan_heavy_global_notifications_json', $json, 'no');

        wp_send_json_success();
    }
}