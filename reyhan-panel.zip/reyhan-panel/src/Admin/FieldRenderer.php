<?php
namespace ReyhanPanel\Admin;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class FieldRenderer {

    private $options;

    public function __construct() {
        $this->options = get_option('reyhan_options');
    }

    public function get_option( $key, $default = '' ) {
        $heavy_keys = ['ticket_faqs', 'ticket_support_agents_data', 'panel_menu_structure'];
        if(in_array($key, $heavy_keys)) {
            $val = get_option('reyhan_heavy_' . $key);
            if($val === false && isset($this->options[$key])) {
                return $this->options[$key];
            }
            return $val !== false ? $val : $default;
        }
        return $this->options[$key] ?? $default;
    }

    public function text($args) {
        $val = esc_attr($this->get_option($args['id']));
        echo "<input type='text' name='reyhan_options[{$args['id']}]' value='$val' class='regular-text' id='{$args['id']}'>";
        
        // تغییر مهم: استفاده از wp_kses_post به جای esc_html برای اجازه دادن به نمایش باکس‌های رنگی
        if(!empty($args['desc'])) {
            echo "<div class='description' style='margin-top:5px; color:#666;'>" . wp_kses_post($args['desc']) . "</div>";
        }
    }
    
    public function text_small($args) {
        $val = esc_attr($this->get_option($args['id']));
        echo "<input type='text' name='reyhan_options[{$args['id']}]' value='{$val}' style='width:80px; text-align:center;'> " . esc_html($args['desc'] ?? '');
    }

    public function textarea_small($args) {
        $val = esc_textarea($this->get_option($args['id']));
        echo "<textarea name='reyhan_options[{$args['id']}]' rows='2' class='large-text'>$val</textarea>";
    }

    public function checkbox($args) {
        $key = $args['id'];
        $val = $this->get_option($key, 0);
        echo '<div style="display:flex; align-items:center; gap:10px;"><input type="hidden" name="reyhan_options['.$key.']" value="0"><input type="checkbox" id="'.$key.'" name="reyhan_options['.$key.']" value="1" '.checked($val, 1, false).'><label for="'.$key.'"></label><span class="rp-toggle-label" style="margin-right:10px;">'.wp_kses_post($args['label']).'</span></div>';
    }

    public function checkbox_toggle_wrapper($args) {
        $key = $args['id'];
        $val = $this->get_option($key, 0);
        echo '<div style="display:flex; align-items:center; gap:10px;"><input type="hidden" name="reyhan_options['.$key.']" value="0"><input type="checkbox" id="'.$key.'" name="reyhan_options['.$key.']" value="1" '.checked($val, 1, false).' class="rp-section-toggle" data-target="'.$args['wrapper_id'].'"><label for="'.$key.'"></label><span class="rp-toggle-label" style="margin-right:10px;">'.wp_kses_post($args['label']).'</span></div>';
        if(!empty($args['desc'])) echo '<p class="description" style="margin-top:5px; color:#666;">'.wp_kses_post($args['desc']).'</p>';
    }

    public function text_modern($args) {
        $val = esc_attr($this->get_option($args['id']));
        $ph = isset($args['placeholder']) ? $args['placeholder'] : __('مثال: jpg, png, zip', 'reyhan-panel');
        echo '<div class="rp-modern-input-wrap"><span class="dashicons dashicons-media-code rp-input-icon"></span><input type="text" name="reyhan_options['.$args['id'].']" value="'.$val.'" class="rp-modern-text-field" placeholder="'.esc_attr($ph).'"></div>';
        if(!empty($args['desc'])) echo '<p class="rp-modern-desc">'.esc_html($args['desc']).'</p>';
    }

    // --- انتخاب فونت (بدون تداخل) ---
    public function render_conflict_free_font_selector($args) {
        $key = $args['id'];
        $current = $this->get_option($key, 'yekan');
        
        $fonts = [
            'yekan' => ['name' => 'یکان بخ (پیشفرض)', 'family' => 'ReyhanFont, Tahoma, sans-serif'],
            'tahoma' => ['name' => 'تاهوما (سیستمی)', 'family' => 'Tahoma, Arial, sans-serif'],
        ];

        echo '<div class="rp-safe-grid-wrapper">';
        foreach ($fonts as $font_key => $font) {
            $is_active = ($current === $font_key);
            echo '<div class="rp-safe-font-card ' . ($is_active ? 'rp-active' : '') . '" onclick="document.getElementById(\'rp-font-' . esc_attr($font_key) . '\').click();">';
            echo '<input type="radio" id="rp-font-' . esc_attr($font_key) . '" name="reyhan_options[' . $key . ']" value="' . esc_attr($font_key) . '" ' . checked($is_active, true, false) . ' style="display:none !important;">';
            echo '<span class="rp-safe-font-name" style="font-family: ' . esc_attr($font['family']) . ' !important;">' . esc_html($font['name']) . '</span>';
            echo '<div class="rp-safe-check-circle"><span class="dashicons dashicons-yes"></span></div>';
            echo '</div>';
        }
        echo '</div>';
        
        echo "<script>
        jQuery(document).ready(function($){ 
            $('.rp-safe-font-card input').change(function(){ 
                $('.rp-safe-font-card').removeClass('rp-active'); 
                $(this).closest('.rp-safe-font-card').addClass('rp-active'); 
            }); 
        });
        </script>";
        
        if(!empty($args['desc'])) echo '<p class="description" style="margin-top:10px;">'.esc_html($args['desc']).'</p>';
    }

    public function section_title($args) {
        echo '<div class="rp-section-header"><span class="rp-section-main-title">' . esc_html($args['title']) . '</span>';
        if(!empty($args['desc'])) echo '<span class="rp-section-sub-title">' . esc_html($args['desc']) . '</span>';
        echo '</div>';
    }

    public function select_auth($args) {
        $val = $this->get_option($args['id'], 'sms');
        echo "<select name='reyhan_options[{$args['id']}]'>
                <option value='sms' ".selected($val,'sms',false).">".__('شماره همراه (OTP)', 'reyhan-panel')."</option>
                <option value='email' ".selected($val,'email',false).">".__('ایمیل', 'reyhan-panel')."</option>
              </select>";
    }

    public function select_provider() {
        // تغییر پیش‌فرض به 'none' (انتخاب نشده)
        $val = $this->get_option('sms_provider', 'none');
        ?>
        <select name='reyhan_options[sms_provider]' id="rp_sms_provider_select" style="min-width: 250px;">
            <option value='none' <?php selected($val, 'none'); ?>>-- انتخاب نشده --</option>
            
            <option value='melipayamak' <?php selected($val, 'melipayamak'); ?>>ملی پیامک</option>
            <option value='smsir' <?php selected($val, 'smsir'); ?>>SMS.ir</option>
            <option value='kaveh' <?php selected($val, 'kaveh'); ?>>کاوه نگار</option>
            <option value='faraz' <?php selected($val, 'faraz'); ?>>فراز اس‌ام‌اس</option>
            <option value='payamito' <?php selected($val, 'payamito'); ?>>پیامیتو</option>
            <option value='payamresan' <?php selected($val, 'payamresan'); ?>>پیام‌رسان</option>
            <option value='other' <?php selected($val, 'other'); ?>>سایر / سرویس خارجی (وب‌سرویس URL)</option>
        </select>
        
        <script>
        jQuery(document).ready(function($){
            function checkProvider() {
                var p = $('#rp_sms_provider_select').val();
                // فقط اگر گزینه‌های "سایر" یا "پیام‌رسان" باشند، فیلد URL را نشان بده
                if( ['other', 'payamresan'].includes(p) ) {
                    $('#row_sms_generic_url').slideDown();
                } else {
                    $('#row_sms_generic_url').slideUp();
                }
            }
            $('#rp_sms_provider_select').change(checkProvider);
            checkProvider();
        });
        </script>
        <?php
    }

    public function text_generic_url($args) {
        $val = esc_url($this->get_option($args['id'])); 
        echo '<div id="row_sms_generic_url" style="display:none; margin-top:15px; padding:15px; background:#f0f4c3; border:1px dashed #c0ca33; border-radius:5px;">';
        echo '<div style="margin-bottom:10px; font-weight:bold;"><span class="dashicons dashicons-admin-links"></span> '.esc_html__('لینک ارسال پیامک (Webservice URL):', 'reyhan-panel').'</div>';
        echo '<input type="text" name="reyhan_options['.$args['id'].']" value="'.$val.'" class="large-text code" style="direction:ltr; text-align:left;" placeholder="https://api.example.com/send?key=API&to=%mobile%&msg=%text%">';
        echo '<p class="description" style="margin-top:8px;">'.esc_html__('از متغیرهای %mobile% برای شماره و %text% برای متن استفاده کنید.', 'reyhan-panel').'</p>';
        echo '</div>';
    }

    public function select_page($args) {
        $val = $this->get_option($args['id'], 0);
        wp_dropdown_pages(['name'=>"reyhan_options[{$args['id']}]",'selected'=>$val,'show_option_none'=>__('— غیرفعال —', 'reyhan-panel')]);
        if(!empty($args['desc'])) echo "<p class='description'>".esc_html($args['desc'])."</p>";
    }

    public function media_upload($args) {
        $id = $args['id'];
        $val = $this->get_option($id);
        
        // تنظیم تصویر پیش‌فرض بر اساس نوع فیلد
        // اگر فیلد مربوط به لوگو باشد، از header.webp استفاده کن، در غیر این صورت user.png
        if ( strpos($id, 'logo') !== false ) {
            $default_image = \REYHAN_URL . 'assets/images/header.webp';
        } else {
            $default_image = \REYHAN_URL . 'assets/images/user.png';
        }
        
        $preview_src = !empty($val) ? esc_url($val) : $default_image;
        $has_image_class = (!empty($val) && $val !== $default_image) ? 'has-image' : '';
        
        // دریافت عنوان و توضیحات از آرگومان‌ها (یا مقادیر پیش‌فرض)
        $title = isset($args['title']) ? $args['title'] : __('انتخاب تصویر', 'reyhan-panel');
        $desc = isset($args['desc']) ? $args['desc'] : '';
        
        ?>
        <div class="rp-media-upload-modern-wrap <?php echo esc_attr( $has_image_class ); ?>" data-id="<?php echo esc_attr($id); ?>">
            <div class="rp-media-preview-box">
                <div class="rp-preview-circle">
                    <img src="<?php echo esc_url( $preview_src ); ?>" data-default="<?php echo esc_url( $default_image ); ?>" class="rp-preview-img">
                    <div class="rp-preview-overlay"><span class="dashicons dashicons-camera"></span></div>
                </div>
            </div>
            <div class="rp-media-controls">
                <h4 class="rp-media-title"><?php echo esc_html($title); ?></h4>
                
                <?php if(!empty($desc)): ?>
                    <p class="rp-media-desc"><?php echo wp_kses_post($desc); ?></p>
                <?php endif; ?>

                <div class="rp-media-buttons">
                    <input type="text" name="reyhan_options[<?php echo esc_attr($id); ?>]" value="<?php echo esc_attr($val); ?>" class="rp-media-input" style="display:none;">
                    
                    <button type="button" class="button rp-upload-btn-modern" data-filter="image">
                        <span class="dashicons dashicons-upload"></span> <?php esc_html_e('انتخاب تصویر', 'reyhan-panel'); ?>
                    </button>
                    
                    <button type="button" class="button rp-remove-btn-modern" style="<?php echo empty($val) ? 'display:none;' : ''; ?>">
                        <span class="dashicons dashicons-trash"></span> <?php esc_html_e('حذف', 'reyhan-panel'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }

    public function recaptcha_block($args) {
        $isActive = !empty($this->get_option($args['parent_active'])); $style = $isActive ? '' : 'display:none;';
        $site = esc_attr($this->get_option('recaptcha_site_key')); 
        $secret = esc_attr($this->get_option('recaptcha_secret_key'));
        echo "<div id='wrap_recaptcha' class='rp-conditional-block' style='{$style}'>
                <p><label>".__('Site Key (کلید سایت):', 'reyhan-panel')."</label><br><input type='text' name='reyhan_options[recaptcha_site_key]' value='{$site}' class='regular-text' style='width:100%'></p>
                <p><label>".__('Secret Key (کلید مخفی):', 'reyhan-panel')."</label><br><input type='text' name='reyhan_options[recaptcha_secret_key]' value='{$secret}' class='regular-text' style='width:100%'></p>
              </div>";
    }

    public function repeater_general($args) {
        $items = $this->get_option($args['id'], []); 
        if(!is_array($items)) $items = []; 
        $fields = $args['fields'];
        
        echo '<input type="hidden" name="reyhan_options['.$args['id'].']" value="">';
        echo '<div class="rp-repeater-wrap rp-repeater-section" data-id="'.$args['id'].'"><div class="rp-repeater-list">';
        foreach($items as $index => $item) {
            echo '<div class="rp-repeater-item"><div class="rp-repeater-inputs">';
            foreach($fields as $key => $label) {
                $val = esc_attr($item[$key] ?? ''); 
                $name = 'reyhan_options['.$args['id'].']['.$index.']['.$key.']';
                echo '<div class="rp-input-group-row"><label class="rp-input-label">'.esc_html($label).'</label>';
                if($key=='content'||$key=='a') echo '<textarea name="'.$name.'" rows="2" class="rp-full-width">'.$val.'</textarea>';
                else echo '<input type="text" name="'.$name.'" value="'.$val.'" class="rp-full-width">';
                echo '</div>';
            }
            echo '</div><div class="rp-repeater-actions"><button type="button" class="button rp-remove-row"><span class="dashicons dashicons-no"></span></button></div></div>';
        }
        $btn_text = isset($args['btn_text']) ? $args['btn_text'] : __('افزودن آیتم', 'reyhan-panel');
        echo '</div><button type="button" class="button rp-add-row" data-fields=\''.json_encode($fields).'\'>+ '.esc_html($btn_text).'</button></div>';
    }

    public function sms_config_block($args) { 
        $base = $args['base_id']; $isActive = !empty($this->get_option($args['parent_active'])); $style = $isActive ? '' : 'display:none;'; 
        $method = $this->get_option($base.'_method', 'pattern'); $pattern = esc_attr($this->get_option($base.'_pattern')); $text = esc_textarea($this->get_option($base.'_text')); 
        echo "<div id='wrap_{$base}' class='rp-conditional-block' style='{$style}'><input type='hidden' name='reyhan_options[{$base}_method]' class='rp-sms-method-input' value='{$method}'>";
        ?>
        <div class="rp-mini-tabs-wrapper">
            <ul class="rp-mini-tabs-nav">
                <li data-method="pattern" class="<?php echo ($method === 'pattern') ? 'active' : ''; ?>"><span class="dashicons dashicons-grid-view"></span> <?php esc_html_e('ارسال با پترن', 'reyhan-panel'); ?></li>
                <li data-method="text" class="<?php echo ($method === 'text') ? 'active' : ''; ?>"><span class="dashicons dashicons-text"></span> <?php esc_html_e('ارسال عادی', 'reyhan-panel'); ?></li>
            </ul>
            <div class="rp-mini-tab-content content-pattern" style="display: <?php echo ($method === 'pattern') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group"><label><?php esc_html_e('کد پترن (Template ID):', 'reyhan-panel'); ?></label><input type="text" name="reyhan_options[<?php echo $base; ?>_pattern]" value="<?php echo esc_attr( $pattern ); ?>" class="regular-text" placeholder="123456"></div>
            </div>
            <div class="rp-mini-tab-content content-text" style="display: <?php echo ($method === 'text') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group"><label><?php esc_html_e('متن پیامک:', 'reyhan-panel'); ?></label><textarea name="reyhan_options[<?php echo $base; ?>_text]" rows="3" class="large-text"><?php echo esc_textarea( $text ); ?></textarea></div>
            </div>
        </div>
        <?php echo "</div>"; 
    }

    public function email_config_block($args) { 
        $base = $args['base_id']; $isActive = !empty($this->get_option($args['parent_active'])); $style = $isActive ? '' : 'display:none;'; 
        $subject = esc_attr($this->get_option($base.'_subject')); $body = $this->get_option($base.'_body'); 
        echo "<div id='wrap_{$base}' class='rp-conditional-block' style='{$style}'><p><label style='font-weight:bold;'>".__('موضوع:', 'reyhan-panel')."</label><br><input type='text' name='reyhan_options[{$base}_subject]' value='{$subject}' class='regular-text' style='width:100%;'></p><p style='font-weight:bold;'>".__('متن:', 'reyhan-panel')."</p>";
        wp_editor($body, $base.'_body', ['textarea_name' => "reyhan_options[$base"."_body]", 'textarea_rows' => 10, 'media_buttons' => true, 'teeny' => false]); 
        if(!empty($args['help'])) echo "<p class='description' style='margin-top:10px;'>".esc_html($args['help'])."</p>"; echo "</div>"; 
    }

    public function global_sms_integrated() {
        $method = $this->get_option('sms_send_method', 'pattern'); 
        $pattern = esc_attr($this->get_option('sms_pattern_otp')); 
        $text = esc_textarea($this->get_option('sms_text_template'));
        
        echo '<input type="hidden" name="reyhan_options[sms_send_method]" id="rp_sms_method_input" value="'.$method.'">';
        ?>
        <div class="rp-mini-tabs-wrapper">
            <ul class="rp-mini-tabs-nav">
                <li data-method="pattern" class="<?php echo ($method === 'pattern') ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-grid-view"></span> <?php esc_html_e('ارسال با پترن', 'reyhan-panel'); ?>
                </li>
                <li data-method="text" class="<?php echo ($method === 'text') ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-text"></span> <?php esc_html_e('ارسال عادی', 'reyhan-panel'); ?>
                </li>
            </ul>

            <div class="rp-mini-tab-content content-pattern" style="display: <?php echo ($method === 'pattern') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group">
                    <label><?php esc_html_e('کد پترن (Template ID):', 'reyhan-panel'); ?></label>
                    <input type="text" name="reyhan_options[sms_pattern_otp]" value="<?php echo esc_attr( $pattern ); ?>" class="regular-text rp-input-modern" placeholder="مثال: 12345">
                </div>

                <div class="rp-guide-box">
                    <div class="rp-guide-title">
                        <span class="dashicons dashicons-info"></span> راهنمای ارسال سریع (پترن)
                    </div>
                    <p>در این روش پیامک‌ها با سرعت بالا (کمتر از ۵ ثانیه) و حتی به شماره‌های لیست سیاه (Blacklist) ارسال می‌شوند. برای استفاده، باید در پنل پیامکی خود یک پترن بسازید.</p>
                    <div class="rp-var-list">
                        <div class="rp-var-item"><span>کد تایید:</span> <span class="rp-var-code">%code%</span></div>
                        <div class="rp-var-item"><span>نام کاربر:</span> <span class="rp-var-code">%username%</span></div>
                    </div>
                    <p style="margin-top:8px; font-size:11px; opacity:0.8;">نکته: متغیرها در پنل پیامک باید دقیقاً به همین شکل تعریف شوند.</p>
                </div>
            </div>

            <div class="rp-mini-tab-content content-text" style="display: <?php echo ($method === 'text') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group">
                    <label><?php esc_html_e('متن کامل پیامک:', 'reyhan-panel'); ?></label>
                    <textarea name="reyhan_options[sms_text_template]" rows="4" class="large-text rp-input-modern" placeholder="متن پیام خود را بنویسید..."><?php echo esc_textarea( $text ); ?></textarea>
                </div>

                <div class="rp-guide-box" style="border-right-color: #4caf50; background: #f1f8e9; border-color: #c8e6c9;">
                    <div class="rp-guide-title" style="color: #2e7d32; border-bottom-color: #c8e6c9;">
                        <span class="dashicons dashicons-text"></span> راهنمای ارسال عادی (تبلیغاتی)
                    </div>
                    <p>در این روش پیامک از خط اختصاصی شما ارسال می‌شود. ممکن است به شماره‌هایی که تبلیغات را بسته‌اند نرسد، اما متن آن کاملاً دلخواه است.</p>
                    <div class="rp-var-list">
                        <div class="rp-var-item"><span>کد تایید:</span> <span class="rp-var-code">%code%</span></div>
                        <div class="rp-var-item"><span>نام کاربر:</span> <span class="rp-var-code">%username%</span></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function login_theme_selector() {
        $current = $this->get_option('login_active_theme', 'default');
        $themes = [ 'default' => ['name'=>'پیشفرض (آتشین)', 'img'=>'t0.png'], 'theme_1' => ['name'=>'سبز (طبیعت)', 'img'=>'t1.png'], 'theme_2' => ['name'=>'آبی (اقیانوس)', 'img'=>'t2.png'], 'theme_3' => ['name'=>'بنفش (آرامش)', 'img'=>'t3.png'], 'theme_4' => ['name'=>'یاسی (طراوت)', 'img'=>'t4.png'] ];
        $this->render_theme_grid($themes, $current, 'login_active_theme', 'rp_login_theme_input');
    }

    public function theme_selector() {
        $current = $this->get_option('panel_active_theme', 'default');
        $themes = [ 'default' => ['name'=>'پیشفرض (آتشین)', 'img'=>'t0.png'], 'theme_1' => ['name'=>'سبز (طبیعت)', 'img'=>'t1.png'], 'theme_2' => ['name'=>'آبی (اقیانوس)', 'img'=>'t2.png'], 'theme_3' => ['name'=>'بنفش (آرامش)', 'img'=>'t3.png'], 'theme_4' => ['name'=>'یاسی (طراوت)', 'img'=>'t4.png'] ];
        $this->render_theme_grid($themes, $current, 'panel_active_theme', 'rp_active_theme_input');
    }

    private function render_theme_grid($themes, $current, $option_name, $input_id) {
        ?>
        <div class="rp-theme-grid">
            <?php foreach($themes as $key => $theme): $active_class = ($current === $key) ? 'active' : ''; $img_url = \REYHAN_URL . 'assets/images/' . $theme['img']; ?>
                <div class="rp-theme-card <?php echo esc_attr( $active_class ); ?>" onclick="jQuery(this).addClass('active').siblings().removeClass('active'); jQuery('#<?php echo esc_attr( $input_id ); ?>').val('<?php echo esc_attr( $key ); ?>');">
                    <img src="<?php echo esc_url($img_url); ?>" class="rp-theme-img" alt="<?php echo esc_attr($theme['name']); ?>">
                    <div class="rp-theme-name"><?php echo esc_html($theme['name']); ?></div>
                </div>
            <?php endforeach; ?>
            <input type="hidden" name="reyhan_options[<?php echo $option_name; ?>]" id="<?php echo esc_attr( $input_id ); ?>" value="<?php echo esc_attr($current); ?>">
        </div>
        <?php
    }

    public function ticket_signatures() {
        $header = esc_textarea($this->get_option('ticket_reply_header'));
        $footer = esc_textarea($this->get_option('ticket_reply_footer'));
        ?>
        <div class="rp-signature-grid" style="display:flex; gap:20px;">
            <div class="rp-sig-box header" style="flex:1;">
                <div class="rp-sig-title" style="margin-bottom:5px; font-weight:bold;"><?php esc_html_e('پیشوند (شروع پیام)', 'reyhan-panel'); ?></div>
                <textarea name="reyhan_options[ticket_reply_header]" style="width:100%; border:1px solid #ddd; border-radius:5px; padding:8px;" rows="4" placeholder="<?php esc_attr_e('مثال: با سلام...', 'reyhan-panel'); ?>"><?php echo esc_textarea( $header ); ?></textarea>
            </div>
            <div class="rp-sig-box footer" style="flex:1;">
                <div class="rp-sig-title" style="margin-bottom:5px; font-weight:bold;"><?php esc_html_e('پسوند (امضاء)', 'reyhan-panel'); ?></div>
                <textarea name="reyhan_options[ticket_reply_footer]" style="width:100%; border:1px solid #ddd; border-radius:5px; padding:8px;" rows="4" placeholder="<?php esc_attr_e('مثال: ارادتمند...', 'reyhan-panel'); ?>"><?php echo esc_textarea( $footer ); ?></textarea>
            </div>
        </div>
        <?php
    }

    public function user_search_manager($args) { 
        $raw_data = $this->get_option('ticket_support_agents_data', '[]');
        if(empty($raw_data)) $raw_data = '[]';
        $depts = $this->get_option('ticket_departments', []);
        $dept_list = [];
        if(is_array($depts)) { foreach($depts as $d) { if(!empty($d['name'])) $dept_list[] = $d['name']; } }
        $default_avatar_url = \REYHAN_URL . 'assets/images/user.png';
        ?>
        <script>
            jQuery(document).ready(function($){ 
                var $wrapper = $('.rp-agent-manager-wrapper');
                var $td = $wrapper.closest('td');
                var $tr = $wrapper.closest('tr');
                $tr.find('th').hide();
                $td.attr('colspan', '2');
                $td.css({'padding': '0', 'margin': '0', 'width': '100%'});
            });
            var rp_departments_list = <?php echo json_encode($dept_list); ?>;
            var rp_default_avatar = "<?php echo esc_url($default_avatar_url); ?>";
        </script>
        <div class="rp-agent-manager-wrapper" style="padding: 0 20px 30px 20px; width: 100%;">
            <textarea name="reyhan_options[ticket_support_agents_data]" id="rp_agents_data_json" style="display:none;"><?php echo esc_textarea($raw_data); ?></textarea>
            <div class="rp-section-header" style="margin-top: 30px; margin-bottom: 20px;">
                <span class="rp-section-main-title"><?php esc_html_e('مدیریت کارشناسان پاسخگو', 'reyhan-panel'); ?></span>
                <span class="rp-section-sub-title"><?php esc_html_e('جستجو و افزودن کارشناس به دپارتمان‌ها', 'reyhan-panel'); ?></span>
            </div>
            <div class="rp-agent-search-box">
                <span class="dashicons dashicons-search" style="color:#aaa; margin-left:10px;"></span>
                <input type="text" id="rp-user-search-input" class="rp-agent-search-input" placeholder="<?php esc_attr_e('نام کاربری یا ایمیل را تایپ کنید...', 'reyhan-panel'); ?>" autocomplete="off">
                <div id="rp-search-results"></div>
            </div>
            <div id="rp-agents-grid" class="rp-agents-list"></div>
            <div id="rp-dept-modal" class="rp-modal-overlay">
                <div class="rp-modal-content">
                    <div class="rp-modal-header">
                        <h3><?php esc_html_e('تنظیمات دسترسی', 'reyhan-panel'); ?></h3>
                        <span class="dashicons dashicons-no-alt close-modal rp-modal-close"></span>
                    </div>
                    <div class="rp-modal-body">
                        <div class="rp-modal-user-preview">
                            <img id="modal-agent-avatar" src="" style="border-radius:50%; width:60px; height:60px; border:3px solid #fff; box-shadow:0 2px 10px rgba(0,0,0,0.1);">
                            <div class="rp-user-details">
                                <h3 id="modal-agent-name" style="margin:0 0 5px 0;"></h3>
                                <span class="rp-role-label"><?php esc_html_e('پشتیبان', 'reyhan-panel'); ?></span>
                            </div>
                        </div>
                        <div class="rp-access-section">
                            <label class="rp-access-option all-access">
                                <input type="checkbox" id="dept-all" value="all">
                                <div class="rp-access-text"><strong><?php esc_html_e('دسترسی مدیر کل', 'reyhan-panel'); ?></strong></div>
                            </label>
                            <div class="rp-divider"><span><?php esc_html_e('یا انتخاب دپارتمان‌ها', 'reyhan-panel'); ?></span></div>
                            <div id="dept-list-container" class="rp-dept-grid"></div>
                        </div>
                    </div>
                    <div class="rp-modal-footer">
                        <button type="button" class="button close-modal"><?php esc_html_e('لغو', 'reyhan-panel'); ?></button>
                        <button type="button" id="btn-save-agent" class="button button-primary"><?php esc_html_e('ذخیره تغییرات', 'reyhan-panel'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php 
    }

    public function tool_guide() { 
        echo '<div class="rp-info-box"><h4><span class="dashicons dashicons-info-outline"></span> '.esc_html__('راهنمای عملیات', 'reyhan-panel').'</h4><ul><li><strong>'.esc_html__('پاکسازی کدها:', 'reyhan-panel').'</strong> '.esc_html__('حذف کدهای یکبار مصرف منقضی شده.', 'reyhan-panel').'</li><li><strong>'.esc_html__('بازنشانی تنظیمات:', 'reyhan-panel').'</strong> '.esc_html__('بازگشت تمام تنظیمات افزونه به حالت اولیه.', 'reyhan-panel').'</li><li><strong>'.esc_html__('حذف تیکت‌ها:', 'reyhan-panel').'</strong> '.esc_html__('حذف کامل تمام تیکت‌های پشتیبانی.', 'reyhan-panel').'</li><li><strong>'.esc_html__('حذف کاربران:', 'reyhan-panel').'</strong> '.esc_html__('حذف تمام کاربران سایت (به جز مدیران).', 'reyhan-panel').'</li></ul></div>'; 
    }

    public function tool_danger_zone() { 
        echo '<div class="rp-tool-box rp-danger-box"><div class="rp-tool-row"><span><span class="dashicons dashicons-trash"></span> '.esc_html__('پاکسازی کدهای تایید (OTP)', 'reyhan-panel').'</span><button type="button" class="button rp-run-tool" data-action="clear_otp">'.esc_html__('اجرا', 'reyhan-panel').'</button></div><div class="rp-tool-row"><span><span class="dashicons dashicons-update"></span> '.esc_html__('بازنشانی کل تنظیمات افزونه', 'reyhan-panel').'</span><button type="button" class="button rp-run-tool" data-action="factory_reset">'.esc_html__('اجرا', 'reyhan-panel').'</button></div><hr style="margin:15px 0; border:0; border-top:1px dashed #ffcdd2;"><div class="rp-tool-row"><span><span class="dashicons dashicons-email-alt"></span> '.esc_html__('حذف تمام تیکت‌ها', 'reyhan-panel').'</span><button type="button" class="button button-link-delete rp-run-tool" data-action="nuke_tickets">'.esc_html__('حذف همه', 'reyhan-panel').'</button></div><div class="rp-tool-row"><span><span class="dashicons dashicons-admin-users"></span> '.esc_html__('حذف تمام کاربران (به جز مدیر)', 'reyhan-panel').'</span><button type="button" class="button button-link-delete rp-run-tool" data-action="nuke_users">'.esc_html__('حذف همه', 'reyhan-panel').'</button></div></div>'; 
    }

    public function tool_tester() {
        echo '<div class="rp-tool-box" style="background:#e3f2fd; padding:15px; border-radius:8px;"><div style="margin-bottom:10px; display:flex; gap:10px;"><input type="text" id="test_mobile_input" placeholder="'.esc_attr__('شماره موبایل', 'reyhan-panel').'" class="regular-text"><button type="button" class="button button-primary rp-run-tool" data-action="test_sms">'.esc_html__('تست پیامک', 'reyhan-panel').'</button></div><div style="display:flex; gap:10px;"><input type="text" id="test_email_input" placeholder="'.esc_attr__('ایمیل', 'reyhan-panel').'" class="regular-text"><button type="button" class="button button-primary rp-run-tool" data-action="test_email">'.esc_html__('تست ایمیل', 'reyhan-panel').'</button></div><div id="rp-test-result" style="margin-top:10px;"></div></div>';
    }

    public function tool_shortcodes() { 
        $codes = [
            ['code' => '[reyhan_panel]', 'desc' => __('شورت کد پنل کاربری - درگاه ورود - درگاه عضویت', 'reyhan-panel')]
        ];
        
        echo '<div style="display:flex; flex-direction:column; gap:10px;">';
        foreach($codes as $item) { echo '<div class="rp-code-box" style="justify-content:space-between;"><div style="display:flex; align-items:center; gap:10px;"><span class="dashicons dashicons-shortcode"></span><code dir="ltr" style="font-size:14px;">'.$item['code'].'</code></div><span style="font-size:12px; color:#abb2bf; opacity:0.8;">'.esc_html($item['desc']).'</span></div>'; }
        echo '</div><p class="description" style="margin-top:15px;">'.esc_html__('این شورت‌کد را می‌توانید در هر برگه یا نوشته‌ای قرار دهید.', 'reyhan-panel').'</p>'; 
    }

    // --- نسخه V2 (مدرن و بدون تداخل) برای مدیریت نمایش ---
    public function render_dashboard_visibility_modern_v2() {
        $items = [
            ['id'=>'panel_widget_ticket_hide', 'label'=>__('تیکت‌های باز', 'reyhan-panel'), 'icon'=>'dashicons-tickets-alt'],
            ['id'=>'panel_widget_order_hide', 'label'=>__('سفارشات', 'reyhan-panel'), 'icon'=>'dashicons-cart'],
            ['id'=>'panel_widget_comments_hide', 'label'=>__('دیدگاه‌ها', 'reyhan-panel'), 'icon'=>'dashicons-admin-comments'],
            ['id'=>'panel_widget_days_hide', 'label'=>__('روزهای عضویت', 'reyhan-panel'), 'icon'=>'dashicons-calendar-alt'],
            ['id'=>'panel_widget_discount_hide', 'label'=>__('کد تخفیف', 'reyhan-panel'), 'icon'=>'dashicons-tag']
        ];
        
        echo '<div class="rp-vis-grid-v2">';
        foreach($items as $item) {
            $val = $this->get_option($item['id'], 0);
            $is_hidden = ($val == 1);
            $checked_attr = checked($val, 1, false);
            $state_class = $is_hidden ? 'is-hidden' : 'is-visible';
            
            // استفاده از DIV به جای LABEL برای جلوگیری از تداخل استایل
            echo '<div class="rp-vis-card-v2 '.esc_attr($state_class).'" onclick="document.getElementById(\''.esc_attr($item['id']).'\').click();">';
            
            // چک‌باکس (با رویداد توقف انتشار تا کلیک دوبار انجام نشود)
            echo '<input type="checkbox" id="'.esc_attr($item['id']).'" name="reyhan_options['.$item['id'].']" value="1" '.$checked_attr.' class="rp-vis-check-v2" onclick="event.stopPropagation()">';
            
            echo '<div class="rp-vis-inner-v2">';
                echo '<span class="dashicons '.esc_attr($item['icon']).' rp-vis-icon-v2"></span>';
                echo '<span class="rp-vis-label-v2">'.esc_html($item['label']).'</span>';
            echo '</div>';
            
            $status_text = $is_hidden ? __('مخفی', 'reyhan-panel') : __('نمایان', 'reyhan-panel');
            echo '<span class="rp-vis-badge-v2">'.$status_text.'</span>';
            
            echo '</div>';
        }
        echo '</div>';
        
        // اسکریپت آپدیت آنی کلاس‌ها
        ?>
        <script>
        jQuery(document).ready(function($){
            $('.rp-vis-check-v2').change(function(){
                var $card = $(this).closest('.rp-vis-card-v2');
                var $badge = $card.find('.rp-vis-badge-v2');
                
                if(this.checked){
                    $card.removeClass('is-visible').addClass('is-hidden');
                    $badge.text('<?php esc_html_e('مخفی', 'reyhan-panel'); ?>');
                } else {
                    $card.removeClass('is-hidden').addClass('is-visible');
                    $badge.text('<?php esc_html_e('نمایان', 'reyhan-panel'); ?>');
                }
            });
        });
        </script>
        <?php
    }

    // --- نسخه V2 (مدرن و بدون تداخل) برای باکس تخفیف ---
    public function render_discount_widget_box() {
        $title = esc_attr($this->get_option('panel_widget_discount_title'));
        $code  = esc_attr($this->get_option('panel_widget_discount_text'));
        ?>
        <div class="rp-modern-card-v2" style="clear:both; position:relative; z-index:1;">
            <div class="rp-card-v2-header">
                <div class="rp-card-v2-icon"><span class="dashicons dashicons-tickets-alt"></span></div>
                <div class="rp-card-v2-info">
                    <span class="rp-card-v2-title"><?php esc_html_e('کارت تخفیف داشبورد', 'reyhan-panel'); ?></span>
                    <span class="rp-card-v2-desc"><?php esc_html_e('تنظیمات نمایش کد تخفیف به کاربر', 'reyhan-panel'); ?></span>
                </div>
            </div>
            
            <div class="rp-card-v2-body">
                <div class="rp-field-row">
                    <span class="rp-input-label-text"><?php esc_html_e('عنوان کارت:', 'reyhan-panel'); ?></span>
                    <div class="rp-input-container">
                        <span class="dashicons dashicons-editor-textcolor rp-input-ico"></span>
                        <input type="text" name="reyhan_options[panel_widget_discount_title]" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php esc_attr_e('پیش‌فرض: کد تخفیف شما', 'reyhan-panel'); ?>" class="rp-clean-input">
                    </div>
                    <small class="rp-field-note"><?php esc_html_e('متنی که بالای کد تخفیف نمایش داده می‌شود.', 'reyhan-panel'); ?></small>
                </div>

                <div class="rp-field-row">
                    <span class="rp-input-label-text"><?php esc_html_e('کد تخفیف:', 'reyhan-panel'); ?></span>
                    <div class="rp-input-container">
                        <span class="dashicons dashicons-tag rp-input-ico"></span>
                        <input type="text" name="reyhan_options[panel_widget_discount_text]" value="<?php echo esc_attr( $code ); ?>" placeholder="OFF-2024" class="rp-clean-input code-mode">
                    </div>
                    <small class="rp-field-note"><?php esc_html_e('کد تخفیف جهت نمایش به کاربر.', 'reyhan-panel'); ?></small>
                </div>
            </div>
        </div>
        <?php
    }

    public function menu_builder( $args ) {
        // اسکریپت فیکس کردن ظاهر جدول در وردپرس
        ?>
        <script>
        jQuery(document).ready(function($) {
            var $trigger = $('#rp-open-menu-modal');
            if ($trigger.length) {
                var $td = $trigger.closest('td');
                var $tr = $td.closest('tr');
                $tr.find('th').hide();
                $td.attr('colspan', '2').css({'padding':'0', 'margin':'0'});
            }
        });
        </script>
        <?php

        $value = get_option('reyhan_heavy_panel_menu_structure');
        if ( empty($value) ) {
            $opts = get_option('reyhan_options');
            if ( !empty($opts['panel_menu_structure']) ) {
                $value = $opts['panel_menu_structure'];
            }
        }
        $json_value = is_array($value) ? json_encode($value) : $value;
        if ( empty($json_value) || $json_value === 'null' ) { $json_value = '[]'; }
        
        $has_woo = class_exists('WooCommerce') ? '1' : '0';

        echo '<div class="rp-menu-builder-wrap">';
        echo '<textarea name="reyhan_options[panel_menu_structure]" id="rp_panel_menu_json" style="display:none;">' . esc_textarea($json_value) . '</textarea>';
        
        // Trigger Box
        echo '<div class="rp-menu-trigger-box" id="rp-open-menu-modal">';
        echo '<div class="rp-trigger-icon"><span class="dashicons dashicons-menu"></span></div>';
        echo '<div class="rp-trigger-content">';
        echo '<h3>'.__('مدیریت منوی سایدبار', 'reyhan-panel').'</h3>';
        echo '<p>'.__('برای شخصی‌سازی لینک‌ها و چیدمان منوی کاربری کلیک کنید', 'reyhan-panel').'</p>';
        echo '</div>';
        echo '<div class="rp-trigger-action"></div>';
        echo '</div>'; 

        // New Modern Popup HTML Structure V2
        ?>
        <div id="rp-menu-modal" class="rp-custom-overlay">
            <div class="rp-modal-content">
                
                <div class="rp-modal-header">
                    <div class="rp-hdr-part rp-part-right">
                        <div class="rp-close-icon-btn rp-modal-close" title="<?php esc_attr_e('انصراف', 'reyhan-panel'); ?>">
                            <span class="dashicons dashicons-no-alt"></span>
                        </div>
                    </div>
                    
                    <div class="rp-head-center">
                        <h3><?php esc_html_e('چیدمان منو پنل کاربری', 'reyhan-panel'); ?></h3>
                    </div>
                    
                    <div class="rp-head-side end">
                        <button type="button" id="rp-save-menu-changes" class="button rp-head-btn rp-btn-save">
                            <span class="dashicons dashicons-saved"></span> <?php esc_html_e('ثبت تغییرات', 'reyhan-panel'); ?>
                        </button>
                    </div>
                </div>
                
                <div class="rp-modal-body">
                    
                    <div class="rp-section-block fixed-section">
                        <div class="rp-block-header">
                            <div class="rp-block-title">
                                <span class="dashicons dashicons-info"></span>
                                <?php esc_html_e('آیتم‌های ثابت فقط امکان تغییر نام و آیکون دارند', 'reyhan-panel'); ?>
                            </div>
                        </div>
                        <div id="rp-fixed-items-container" data-has-woo="<?php echo $has_woo; ?>" class="rp-grid-container"></div>
                    </div>

                    <div class="rp-section-divider"></div>
                    
                    <div class="rp-section-block custom-section">
                        <div class="rp-block-header">
                            <button type="button" id="rp-add-custom-item" class="rp-btn-add-modern">
                                    <?php esc_html_e('اضافه کردن آیتم', 'reyhan-panel'); ?>
                                    <div class="icon-plus">
                                            <svg height="24" width="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M11 11V5h2v6h6v2h-6v6h-2v-6H5v-2z" fill="currentColor"></path>
                                            </svg>
                                        </div>
                            </button>
                        </div>
    
                        <div id="rp-custom-items-container" class="rp-list-container"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        echo '</div>'; 

        ?>
        <div id="rp_save_warning_modal" class="rp-logout-modal-overlay" style="display:none; z-index: 1000000;">
            <div class="rp-logout-modal-box">
                <span class="dashicons dashicons-warning rp-logout-icon-large"></span>
                <div class="rp-logout-title"><?php esc_html_e('تغییرات ذخیره نشده', 'reyhan-panel'); ?></div>
                <div class="rp-logout-desc"><?php esc_html_e('تغییراتی اعمال کرده‌اید که ذخیره نشده‌اند. آیا می‌خواهید آنها را ذخیره کنید؟', 'reyhan-panel'); ?></div>
                
                <div class="rp-logout-actions">
                    <button type="button" id="rp-warn-no-save" class="rp-btn-logout-no">
                        <?php esc_html_e('خیر، ببند', 'reyhan-panel'); ?>
                    </button>
                    <button type="button" id="rp-warn-do-save" class="rp-btn-logout-yes">
                        <?php esc_html_e('بله، ذخیره کن', 'reyhan-panel'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }

    private function render_menu_item_row($base_id, $idx, $item) {
        $label = esc_attr($item['label'] ?? ''); 
        $act = $item['action'] ?? 'link';
        $icon = esc_attr($item['icon'] ?? 'dashicons-marker'); 
        $icon_type = $item['icon_type'] ?? 'icon'; 
        $custom_image = esc_attr($item['custom_image'] ?? '');
        $link = esc_attr($item['link'] ?? ''); 
        $shortcode = esc_textarea($item['shortcode'] ?? '');
        
        $display_title = $label ? $label : __('(بدون عنوان)', 'reyhan-panel');
        $is_locked = ($act === 'dashboard' || $act === 'logout');
        $locked_class = $is_locked ? 'rp-locked-item' : '';
        
        $sort_handle = $is_locked ? '<span class="dashicons dashicons-lock rp-lock-icon" title="'.__('این آیتم ثابت است', 'reyhan-panel').'"></span>' : '<span class="dashicons dashicons-move rp-sort-handle"></span>';
        $delete_btn = $is_locked ? '' : '<button type="button" class="rp-remove-row"><span class="dashicons dashicons-trash"></span></button>';
        $action_select_attr = $is_locked ? 'style="pointer-events:none; background:#f0f0f1; opacity:0.7;" readonly' : '';
        
        echo '<div class="rp-repeater-item rp-menu-item-row rp-tree-item closed '.$locked_class.'" data-action="'.$act.'">';
        
        echo '<div class="rp-item-header">';
        echo wp_kses_post( $sort_handle );
        echo '<span class="rp-item-title">'.$display_title.'</span>';
        echo '<div class="rp-header-controls">';
        echo '<span class="rp-item-type-badge">'.$act.'</span>';
        echo '<button type="button" class="rp-toggle-item"><span class="dashicons dashicons-arrow-down-alt2"></span></button>';
        echo wp_kses_post( $delete_btn );
        echo '</div></div>';
        
        echo '<div class="rp-item-body" style="display:none;">';
        
        echo '<div class="rp-row-flex">';
        echo '<div class="rp-col-half"><label>'.__('عنوان', 'reyhan-panel').'</label><input type="text" name="reyhan_options['.$base_id.']['.$idx.'][label]" value="'.$label.'" class="rp-full-input rp-live-title"></div>';
        echo '<div class="rp-col-half"><label>'.__('عملکرد', 'reyhan-panel').'</label>';
        if($is_locked) echo '<input type="hidden" name="reyhan_options['.$base_id.']['.$idx.'][action]" value="'.$act.'">';
        echo '<select name="reyhan_options['.$base_id.']['.$idx.'][action]" class="rp-full-input rp-menu-action-select" '.$action_select_attr.'>';
        echo '<option value="dashboard" '.selected($act,'dashboard',false).'>'.__('داشبورد', 'reyhan-panel').'</option>';
        echo '<option value="tickets" '.selected($act,'tickets',false).'>'.__('تیکت‌ها', 'reyhan-panel').'</option>';
        echo '<option value="orders" '.selected($act,'orders',false).'>'.__('سفارشات', 'reyhan-panel').'</option>';
        echo '<option value="profile" '.selected($act,'profile',false).'>'.__('ویرایش حساب', 'reyhan-panel').'</option>';
        echo '<option value="content" '.selected($act,'content',false).'>'.__('شورت کد', 'reyhan-panel').'</option>';
        echo '<option value="link" '.selected($act,'link',false).'>'.__('لینک', 'reyhan-panel').'</option>';
        echo '<option value="logout" '.selected($act,'logout',false).'>'.__('خروج', 'reyhan-panel').'</option>';
        echo '</select></div></div>';
        
        echo '<div class="rp-icon-settings-box">';
        echo '<div class="rp-icon-type-switch">';
        echo '<label><input type="radio" name="reyhan_options['.$base_id.']['.$idx.'][icon_type]" value="icon" '.checked($icon_type,'icon',false).' class="rp-icon-type-radio"> '.__('آیکون', 'reyhan-panel').'</label>';
        echo '<label><input type="radio" name="reyhan_options['.$base_id.']['.$idx.'][icon_type]" value="image" '.checked($icon_type,'image',false).' class="rp-icon-type-radio"> SVG/تصویر </label>';
        echo '</div>';
        
        echo '<div class="rp-icon-picker-area" style="'.($icon_type=='icon'?'':'display:none').'">';
        echo '<div class="rp-icon-picker-wrap">';
        echo '<button type="button" class="button rp-icon-select-btn"><span class="dashicons '.$icon.' preview-icon"></span> '.__('انتخاب آیکون', 'reyhan-panel').'</button>';
        echo '<input type="hidden" name="reyhan_options['.$base_id.']['.$idx.'][icon]" value="'.$icon.'" class="rp-icon-input">';
        echo '<div class="rp-icon-dropdown"></div>';
        echo '</div></div>';
        
        echo '<div class="rp-image-uploader-area" style="'.($icon_type=='image'?'':'display:none').'">';
        echo '<div style="display:flex;gap:10px">';
        echo '<input type="text" name="reyhan_options['.$base_id.']['.$idx.'][custom_image]" value="'.$custom_image.'" class="regular-text rp-image-url" placeholder="آدرس تصویر">';
        echo '<button type="button" class="button rp-media-upload-btn">'.__('انتخاب', 'reyhan-panel').'</button>';
        echo '</div></div>';
        echo '</div>'; 
        
        echo '<div class="rp-menu-extra-settings">';
        echo '<div class="rp-menu-link-row" style="'.($act=='link'?'':'display:none').'"><label>'.__('لینک:', 'reyhan-panel').'</label><input type="text" name="reyhan_options['.$base_id.']['.$idx.'][link]" value="'.$link.'" class="rp-full-input" dir="ltr"></div>';
        echo '<div class="rp-menu-shortcode-row" style="'.($act=='content'?'':'display:none').'"><label>'.__('شورت‌کد:', 'reyhan-panel').'</label><textarea name="reyhan_options['.$base_id.']['.$idx.'][shortcode]" class="rp-full-input" dir="ltr">'.$shortcode.'</textarea></div>';
        echo '</div>';
        
        echo '</div></div>';
    }

    public function canned_responses_personal($args) {
        $uid = get_current_user_id();
        $items = get_user_meta($uid, 'rp_user_canned_responses', true);
        if(!is_array($items)) $items = []; 
        $fields = $args['fields'];
        $temp_id = 'ticket_canned_personal_temp';
        echo '<input type="hidden" name="reyhan_options['.$temp_id.']" value="">';
        echo '<div class="rp-repeater-wrap rp-repeater-section" data-id="'.$temp_id.'"><div class="rp-repeater-list">';
        foreach($items as $index => $item) {
            echo '<div class="rp-repeater-item"><div class="rp-repeater-inputs">';
            foreach($fields as $key => $label) {
                $val = esc_attr($item[$key] ?? ''); 
                $name = 'reyhan_options['.$temp_id.']['.$index.']['.$key.']';
                echo '<div class="rp-input-group-row"><label class="rp-input-label">'.esc_html($label).'</label>';
                if($key=='content') echo '<textarea name="'.$name.'" rows="2" class="rp-full-width">'.$val.'</textarea>';
                else echo '<input type="text" name="'.$name.'" value="'.$val.'" class="rp-full-width">';
                echo '</div>';
            }
            echo '</div><div class="rp-repeater-actions"><button type="button" class="button rp-remove-row" title="'.__('حذف', 'reyhan-panel').'"><span class="dashicons dashicons-no"></span></button></div></div>';
        }
        $btn_text = isset($args['btn_text']) ? $args['btn_text'] : __('افزودن', 'reyhan-panel');
        echo '</div><button type="button" class="button rp-add-row" data-fields=\''.json_encode($fields).'\'>+ '.esc_html($btn_text).'</button></div>';
        echo '<p class="description">'.esc_html__('این پاسخ‌ها اختصاصی برای شما هستند.', 'reyhan-panel').'</p>';
    }

    public function render_email_welcome_user() {
        $subject = esc_attr($this->get_option('email_user_reg_subject'));
        $body = $this->get_option('email_user_reg_body');
        $isActive = !empty($this->get_option('email_user_reg_active'));
        $style = $isActive ? '' : 'display:none;';
        echo "<div id='wrap_email_user_reg' class='rp-conditional-block' style='{$style}'>";
        echo "<p><label style='font-weight:bold;'>" . __('موضوع ایمیل:', 'reyhan-panel') . "</label><br>";
        echo "<input type='text' name='reyhan_options[email_user_reg_subject]' value='{$subject}' class='regular-text' style='width:100%;'></p>";
        echo "<p style='font-weight:bold;'>" . __('متن ایمیل:', 'reyhan-panel') . "</p>";
        wp_editor($body, 'email_user_reg_body', ['textarea_name' => 'reyhan_options[email_user_reg_body]','textarea_rows' => 10,'media_buttons' => true,'teeny' => false]);
        ?>
        <div class="rp-guide-box" style="border-right-color: #9c27b0; background: #f3e5f5; border-color: #e1bee7; margin-top: 15px;">
            <div class="rp-guide-title" style="color: #7b1fa2; border-bottom-color: #e1bee7;">
                <span class="dashicons dashicons-email-alt"></span> راهنمای متغیرهای ایمیل کاربر
            </div>
            <p>این ایمیل پس از ثبت‌نام موفقیت‌آمیز به کاربر ارسال می‌شود.</p>
            <div class="rp-var-list">
                <div class="rp-var-item"><span>نام کاربری:</span> <span class="rp-var-code">%username%</span></div>
                <div class="rp-var-item"><span>شماره موبایل:</span> <span class="rp-var-code">%mobile%</span></div>
                <div class="rp-var-item"><span>نام سایت:</span> <span class="rp-var-code">%site_name%</span></div>
            </div>
        </div>
        <?php
        echo "</div>";
    }

    public function render_email_notify_admin() {
        $subject = esc_attr($this->get_option('email_admin_reg_subject'));
        $body = $this->get_option('email_admin_reg_body');
        $isActive = !empty($this->get_option('email_admin_reg_active'));
        $style = $isActive ? '' : 'display:none;';
        echo "<div id='wrap_email_admin_reg' class='rp-conditional-block' style='{$style}'>";
        echo "<p><label style='font-weight:bold;'>" . __('موضوع ایمیل:', 'reyhan-panel') . "</label><br>";
        echo "<input type='text' name='reyhan_options[email_admin_reg_subject]' value='{$subject}' class='regular-text' style='width:100%;'></p>";
        echo "<p style='font-weight:bold;'>" . __('متن ایمیل:', 'reyhan-panel') . "</p>";
        wp_editor($body, 'email_admin_reg_body', ['textarea_name' => 'reyhan_options[email_admin_reg_body]','textarea_rows' => 10,'media_buttons' => true,'teeny' => false]);
        ?>
        <div class="rp-guide-box" style="border-right-color: #ff9800; background: #fff3e0; border-color: #ffe0b2; margin-top: 15px;">
            <div class="rp-guide-title" style="color: #e65100; border-bottom-color: #ffe0b2;">
                <span class="dashicons dashicons-admin-users"></span> راهنمای متغیرهای ایمیل مدیر
            </div>
            <p>این ایمیل هنگام ثبت‌نام کاربر جدید برای مدیر ارسال می‌شود.</p>
            <div class="rp-var-list">
                <div class="rp-var-item"><span>نام کاربری:</span> <span class="rp-var-code">%username%</span></div>
                <div class="rp-var-item"><span>شماره موبایل:</span> <span class="rp-var-code">%mobile%</span></div>
            </div>
        </div>
        <?php
        echo "</div>";
    }

    public function render_ticket_email_submit() {
        $isActive = !empty($this->get_option('ticket_email_submit_active'));
        echo '<div id="wrap_ticket_email_submit" class="rp-conditional-block" style="'.($isActive?'':'display:none;').'">';
        echo '<p><label style="font-weight:bold;">'.__('موضوع:', 'reyhan-panel').'</label><br><input type="text" name="reyhan_options[ticket_email_submit_subject]" value="'.esc_attr($this->get_option('ticket_email_submit_subject')).'" class="regular-text" style="width:100%;"></p>';
        echo '<p style="font-weight:bold;">'.__('متن ایمیل:', 'reyhan-panel').'</p>';
        wp_editor($this->get_option('ticket_email_submit_body'), 'ticket_email_submit_body', ['textarea_name'=>'reyhan_options[ticket_email_submit_body]', 'textarea_rows'=>8, 'media_buttons'=>true, 'teeny'=>true]);
        echo '<div class="rp-guide-box" style="border-right-color:#673ab7; background:#ede7f6; border-color:#d1c4e9; margin-top:15px;"><div class="rp-guide-title" style="color:#512da8; border-bottom-color:#d1c4e9;"><span class="dashicons dashicons-email-alt"></span> راهنمای ایمیل ثبت تیکت</div><p>ارسال به کاربر هنگام ثبت تیکت جدید.</p><div class="rp-var-list"><div class="rp-var-item"><span>نام کاربر:</span> <span class="rp-var-code">{username}</span></div><div class="rp-var-item"><span>شناسه تیکت:</span> <span class="rp-var-code">{ticket_id}</span></div><div class="rp-var-item"><span>عنوان:</span> <span class="rp-var-code">{subject}</span></div></div></div>';
        echo '</div>';
    }

    public function render_ticket_email_reply() {
        $isActive = !empty($this->get_option('ticket_email_reply_active'));
        echo '<div id="wrap_ticket_email_reply" class="rp-conditional-block" style="'.($isActive?'':'display:none;').'">';
        echo '<p><label style="font-weight:bold;">'.__('موضوع:', 'reyhan-panel').'</label><br><input type="text" name="reyhan_options[ticket_email_reply_subject]" value="'.esc_attr($this->get_option('ticket_email_reply_subject')).'" class="regular-text" style="width:100%;"></p>';
        echo '<p style="font-weight:bold;">'.__('متن ایمیل:', 'reyhan-panel').'</p>';
        wp_editor($this->get_option('ticket_email_reply_body'), 'ticket_email_reply_body', ['textarea_name'=>'reyhan_options[ticket_email_reply_body]', 'textarea_rows'=>8, 'media_buttons'=>true, 'teeny'=>true]);
        echo '<div class="rp-guide-box" style="border-right-color:#e91e63; background:#fce4ec; border-color:#f8bbd0; margin-top:15px;"><div class="rp-guide-title" style="color:#c2185b; border-bottom-color:#f8bbd0;"><span class="dashicons dashicons-testimonial"></span> راهنمای ایمیل پاسخ تیکت</div><p>ارسال به کاربر پس از پاسخ پشتیبان.</p><div class="rp-var-list"><div class="rp-var-item"><span>شناسه تیکت:</span> <span class="rp-var-code">{ticket_id}</span></div><div class="rp-var-item"><span>متن پاسخ:</span> <span class="rp-var-code">{reply_content}</span></div></div></div>';
        echo '</div>';
    }

    public function render_ticket_sms_submit() {
        $isActive = !empty($this->get_option('ticket_sms_submit_active'));
        $method = $this->get_option('ticket_sms_submit_method', 'pattern');
        $pattern = esc_attr($this->get_option('ticket_sms_submit_pattern'));
        $text = esc_textarea($this->get_option('ticket_sms_submit_text'));
        echo '<div id="wrap_ticket_sms_submit" class="rp-conditional-block" style="'.($isActive?'':'display:none;').'">';
        echo '<input type="hidden" name="reyhan_options[ticket_sms_submit_method]" class="rp-sms-method-input" value="'.$method.'">';
        echo '<div class="rp-mini-tabs-wrapper">';
        echo '<ul class="rp-mini-tabs-nav"><li data-method="pattern" class="'.($method==='pattern'?'active':'').'"><span class="dashicons dashicons-grid-view"></span> '.__('ارسال با پترن', 'reyhan-panel').'</li><li data-method="text" class="'.($method==='text'?'active':'').'"><span class="dashicons dashicons-text"></span> '.__('ارسال عادی', 'reyhan-panel').'</li></ul>';
        echo '<div class="rp-mini-tab-content content-pattern" style="display:'.($method==='pattern'?'block':'none').';"><div class="rp-input-group"><label>'.__('کد پترن:', 'reyhan-panel').'</label><input type="text" name="reyhan_options[ticket_sms_submit_pattern]" value="'.$pattern.'" class="regular-text rp-input-modern" placeholder="مثال: 12345"></div><div class="rp-guide-box" style="border-right-color:#009688; background:#e0f2f1; border-color:#b2dfdb; margin-top:15px;"><div class="rp-guide-title" style="color:#00796b; border-bottom-color:#b2dfdb;"><span class="dashicons dashicons-smartphone"></span> راهنمای پترن ثبت</div><p>ارسال سریع به کاربر.</p><div class="rp-var-list"><div class="rp-var-item"><span>شناسه تیکت:</span> <span class="rp-var-code">%ticket_id%</span></div><div class="rp-var-item"><span>نام کاربر:</span> <span class="rp-var-code">%username%</span></div></div></div></div>';
        echo '<div class="rp-mini-tab-content content-text" style="display:'.($method==='text'?'block':'none').';"><div class="rp-input-group"><label>'.__('متن پیامک:', 'reyhan-panel').'</label><textarea name="reyhan_options[ticket_sms_submit_text]" rows="3" class="large-text rp-input-modern">'.$text.'</textarea></div><div class="rp-guide-box" style="border-right-color:#00796b; background:#e0f2f1; border-color:#b2dfdb; margin-top:15px;"><div class="rp-guide-title" style="color:#00796b; border-bottom-color:#b2dfdb;"><span class="dashicons dashicons-text"></span> راهنمای ارسال عادی</div><p>ارسال با متن دلخواه.</p><div class="rp-var-list"><div class="rp-var-item"><span>شناسه تیکت:</span> <span class="rp-var-code">%ticket_id%</span></div><div class="rp-var-item"><span>نام کاربر:</span> <span class="rp-var-code">%username%</span></div></div></div></div>';
        echo '</div></div>';
    }

    public function render_ticket_sms_reply() {
        $isActive = !empty($this->get_option('ticket_sms_reply_active'));
        $method = $this->get_option('ticket_sms_reply_method', 'pattern');
        $pattern = esc_attr($this->get_option('ticket_sms_reply_pattern'));
        $text = esc_textarea($this->get_option('ticket_sms_reply_text'));
        echo '<div id="wrap_ticket_sms_reply" class="rp-conditional-block" style="'.($isActive?'':'display:none;').'">';
        echo '<input type="hidden" name="reyhan_options[ticket_sms_reply_method]" class="rp-sms-method-input" value="'.$method.'">';
        echo '<div class="rp-mini-tabs-wrapper">';
        echo '<ul class="rp-mini-tabs-nav"><li data-method="pattern" class="'.($method==='pattern'?'active':'').'"><span class="dashicons dashicons-grid-view"></span> '.__('ارسال با پترن', 'reyhan-panel').'</li><li data-method="text" class="'.($method==='text'?'active':'').'"><span class="dashicons dashicons-text"></span> '.__('ارسال عادی', 'reyhan-panel').'</li></ul>';
        echo '<div class="rp-mini-tab-content content-pattern" style="display:'.($method==='pattern'?'block':'none').';"><div class="rp-input-group"><label>'.__('کد پترن:', 'reyhan-panel').'</label><input type="text" name="reyhan_options[ticket_sms_reply_pattern]" value="'.$pattern.'" class="regular-text rp-input-modern" placeholder="مثال: 67890"></div><div class="rp-guide-box" style="border-right-color:#2196f3; background:#e3f2fd; border-color:#bbdefb; margin-top:15px;"><div class="rp-guide-title" style="color:#1565c0; border-bottom-color:#bbdefb;"><span class="dashicons dashicons-smartphone"></span> راهنمای پترن پاسخ</div><p>ارسال سریع پاسخ.</p><div class="rp-var-list"><div class="rp-var-item"><span>شناسه تیکت:</span> <span class="rp-var-code">%ticket_id%</span></div><div class="rp-var-item"><span>وضعیت:</span> <span class="rp-var-code">%status%</span></div></div></div></div>';
        echo '<div class="rp-mini-tab-content content-text" style="display:'.($method==='text'?'block':'none').';"><div class="rp-input-group"><label>'.__('متن پیامک:', 'reyhan-panel').'</label><textarea name="reyhan_options[ticket_sms_reply_text]" rows="3" class="large-text rp-input-modern">'.$text.'</textarea></div><div class="rp-guide-box" style="border-right-color:#1565c0; background:#e3f2fd; border-color:#bbdefb; margin-top:15px;"><div class="rp-guide-title" style="color:#1565c0; border-bottom-color:#bbdefb;"><span class="dashicons dashicons-admin-comments"></span> راهنمای ارسال عادی</div><p>ارسال پاسخ با متن دلخواه.</p><div class="rp-var-list"><div class="rp-var-item"><span>شناسه تیکت:</span> <span class="rp-var-code">%ticket_id%</span></div><div class="rp-var-item"><span>وضعیت:</span> <span class="rp-var-code">%status%</span></div></div></div></div>';
        echo '</div></div>';
    }

    // این تابع را به کلاس FieldRenderer اضافه کنید
    public function render_force_profile_completion($args) {
        $key = $args['id'];
        $val = $this->get_option($key, 0);

        // 1. نمایش چک‌باکس (کد استاندارد تاگل)
        echo '<div style="display:flex; align-items:center; gap:10px;">
                <input type="hidden" name="reyhan_options['.$key.']" value="0">
                <input type="checkbox" id="'.$key.'" name="reyhan_options['.$key.']" value="1" '.checked($val, 1, false).' class="rp-section-toggle" data-target="'.$args['wrapper_id'].'">
                <label for="'.$key.'"></label>
                <span class="rp-toggle-label" style="margin-right:10px;">'.wp_kses_post($args['label']).'</span>
              </div>';

        // 2. نمایش باکس راهنمای زرد رنگ (کد HTML تمیز)
        ?>
        <div class="rp-guide-box">
            <div class="rp-guide-title">
                <span class="dashicons dashicons-info"></span> <?php esc_html_e('نکته مهم (تکمیل اطلاعات)', 'reyhan-panel'); ?>
            </div>
            <p><?php esc_html_e('اگر می‌خواهید کاربر پس از ثبت‌نام حتماً نام و موبایل خود را تکمیل کند، این گزینه را فعال کنید.', 'reyhan-panel'); ?></p>
            <div class="rp-var-list">
                <div class="rp-var-item" style="width:100%; display:block;">
                    <span><?php esc_html_e('در صورت غیرفعال بودن، کاربر می‌تواند اطلاعات را بعداً به دلخواه در ویرایش پروفایل وارد کند.', 'reyhan-panel'); ?></span>
                </div>
            </div>
        </div>
        <?php
    }
}