<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

$status = get_post_meta( $t->ID, '_ticket_status', true );

$status_labels = [
    'answered' => __('پاسخ داده شده', 'reyhan-panel'),
    'closed'   => __('بسته شده', 'reyhan-panel'),
    'open'     => __('باز', 'reyhan-panel'),
    'user_reply' => __('پاسخ کاربر', 'reyhan-panel'),
    'pending'  => __('در انتظار', 'reyhan-panel')
];

$st_label = isset($status_labels[$status]) ? $status_labels[$status] : $status;
?>
<tr>
    <td>#<?php echo intval($t->ID); ?></td>
    <td><?php echo esc_html($t->post_title); ?></td>
    <td>
        <span class="rp-badge rp-status-<?php echo esc_attr($status); ?>">
            <?php echo esc_html($st_label); ?>
        </span>
    </td>
    <td><?php echo esc_html( get_the_date('Y/m/d', $t) ); ?></td>
    <td>
        <button class="t-view-link" onclick="window.loadSingleTicket(<?php echo intval($t->ID); ?>)">
            <?php esc_html_e('مشاهده', 'reyhan-panel'); ?>
        </button>
    </td>
</tr>