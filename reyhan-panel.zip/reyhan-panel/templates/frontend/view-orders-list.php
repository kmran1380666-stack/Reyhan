<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; } 

if ( ! class_exists( 'WooCommerce' ) ) {
    echo '<div class="rp-error">' . esc_html__('فروشگاه ووکامرس فعال نیست.', 'reyhan-panel') . '</div>';
    return;
}
?>

<div class="rp-orders-wrapper">
    <?php if ( ! empty( $orders ) ) : ?>
        <table class="rp-orders-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'شماره سفارش', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'تاریخ', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'وضعیت', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'مبلغ کل', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'عملیات', 'reyhan-panel' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $orders as $order_id ) : 
                    $order = wc_get_order( $order_id );
                    if ( ! $order ) continue;
                    
                    $status_label = wc_get_order_status_name( $order->get_status() );
                    $status_class = 'rp-order-status-' . esc_attr( $order->get_status() );
                    ?>
                    <tr>
                        <td>
                            <span class="rp-order-id">#<?php echo esc_html( $order->get_order_number() ); ?></span>
                        </td>
                        <td>
                            <span class="rp-order-date"><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></span>
                        </td>
                        <td>
                            <span class="rp-badge <?php echo esc_attr( $status_class ); ?>">
                                <?php echo esc_html( $status_label ); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo wp_kses_post( $order->get_formatted_order_total() ); ?>
                        </td>
                        <td>
                            <button class="rp-btn-view-order" onclick="ReyhanApp.loadSingleOrder(<?php echo intval( $order->get_id() ); ?>)">
                                <?php esc_html_e( 'جزئیات', 'reyhan-panel' ); ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        
        <div class="rp-empty-state-modern">
            <div class="rp-es-icon-box">
                <span class="dashicons dashicons-cart"></span>
            </div>
            <div class="rp-es-title"><?php esc_html_e( 'لیست سفارشات شما خالی است!', 'reyhan-panel' ); ?></div>
            <div class="rp-es-desc"><?php esc_html_e( 'شما هنوز هیچ سفارشی در فروشگاه ثبت نکرده‌اید. همین حالا محصولات ما را بررسی کنید.', 'reyhan-panel' ); ?></div>
            
            <a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="rp-btn-shop-now">
                <span class="dashicons dashicons-store"></span>
                <?php esc_html_e( 'شروع خرید از فروشگاه', 'reyhan-panel' ); ?>
            </a>
        </div>

    <?php endif; ?>
</div>