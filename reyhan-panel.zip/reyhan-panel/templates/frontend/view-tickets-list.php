<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="rp-tickets-wrapper">
    <?php if ( ! empty( $tickets ) && is_array( $tickets ) ) : ?>
        <table class="rp-orders-table rp-tickets-table">
            <thead>
                <tr>
                    <th>شناسه</th>
                    <th>موضوع</th>
                    <th>بخش</th>
                    <th>وضعیت</th>
                    <th>بروزرسانی</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $tickets as $ticket ) : 
                    // اطمینان از اینکه آبجکت پست است
                    if ( ! is_a( $ticket, 'WP_Post' ) ) continue;
                    
                    $tid = $ticket->ID;
                    $code = get_post_meta( $tid, '_ticket_code', true ) ?: $tid;
                    $dept = get_post_meta( $tid, '_ticket_department', true ) ?: 'عمومی';
                    $status = get_post_meta( $tid, '_ticket_status', true ) ?: 'open';
                    $date = get_the_modified_date( 'Y/m/d', $tid );
                    
                    $status_map = [
                        'open' => ['باز', 'rp-status-open'],
                        'closed' => ['بسته شده', 'rp-status-closed'],
                        'answered' => ['پاسخ داده شده', 'rp-status-answered'],
                        'user_reply' => ['پاسخ شما', 'rp-status-pending'],
                        'admin_reply' => ['پاسخ پشتیبان', 'rp-status-answered']
                    ];
                    
                    $st_info = isset($status_map[$status]) ? $status_map[$status] : [$status, ''];
                ?>
                <tr>
                    <td><span class="rp-order-id">#<?php echo esc_html( $code ); ?></span></td>
                    <td class="rp-ticket-subject"><strong><?php echo esc_html( $ticket->post_title ); ?></strong></td>
                    <td><span class="rp-dept-badge"><?php echo esc_html( $dept ); ?></span></td>
                    <td><span class="rp-badge <?php echo esc_attr($st_info[1]); ?>"><?php echo esc_html( $st_info[0] ); ?></span></td>
                    <td class="rp-date-col"><?php echo esc_html( $date ); ?></td>
                    <td>
                        <button class="rp-btn-view-order" onclick="ReyhanApp.loadSingleTicket(<?php echo intval( $tid ); ?>)">مشاهده</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <div class="rp-empty-state-modern">
            <div class="rp-es-icon-box"><span class="dashicons dashicons-email-alt"></span></div>
            <div class="rp-es-title">هنوز تیکتی ثبت نکرده‌اید</div>
            <div class="rp-es-desc">برای ارتباط با پشتیبانی، اولین تیکت خود را ارسال کنید.</div>
        </div>
    <?php endif; ?>
</div>