<input type="hidden" id="rp_admin_nonce" value="<?php echo wp_create_nonce('rp_admin_nonce'); ?>">

<?php 
// اصلاح: اولویت با داده‌های Heavy است تا با فرانت‌اند هماهنگ باشد
$notifications_json = get_option('reyhan_heavy_global_notifications_json');

if ( ! is_string($notifications_json) || empty($notifications_json) || $notifications_json === '[]' ) {
    // اگر در Heavy نبود، از آپشن قدیمی بخوان (برای سازگاری)
    $options = get_option('reyhan_options', []);
    $notifications_json = $options['global_notifications_json'] ?? '[]';
}
?>
<textarea id="rp-notif-initial-data" style="display:none;"><?php echo esc_textarea($notifications_json); ?></textarea>

<div class="wrap reyhanpanel-wrap">
    <div class="rp-header-hero">
        <div class="rp-hero-icon-box">
            <span class="dashicons dashicons-admin-settings"></span>
        </div>
        <div class="rp-hero-content">
            <h1><?php esc_html_e('اطلاعیه های سراسری', 'reyhan-panel'); ?></h1>
            <p><?php esc_html_e('در این بخش میتوانید اطلاعیه های خود را ثبت، ویرایش یا حذف کنید.', 'reyhan-panel'); ?></p>
        </div>
    </div>
    
    <?php 
    if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
        echo '<div id="reyhan-toast-msg" class="rp-modern-toast"><span class="dashicons dashicons-saved"></span> <span>'.esc_html__('تغییرات با موفقیت ذخیره شد.', 'reyhan-panel').'</span></div>';
    }
    ?>
    
    <form method="post" action="options.php" id="rp-notif-main-form">
        <?php settings_fields('reyhan_master_group'); ?>
        
        <textarea name="reyhan_options[global_notifications_json]" id="rp_notif_data_json" style="display:none;"></textarea>
        
        <div class="rp-notif-container">
            <div class="rp-notif-top-bar">
                <div class="rp-top-info">
                    <h2><?php esc_html_e('لیست اطلاعیه ها', 'reyhan-panel'); ?></h2>
                    <p><?php esc_html_e('تمامی این اطلاعیه ها در بالای تمامی پنل های کاربری کاربران نمایش داده میشود', 'reyhan-panel'); ?></p>
                </div>
                <button type="button" id="rp-btn-add-new" class="rp-btn-primary-large">
                    <span class="dashicons dashicons-plus"></span> <?php esc_html_e('ایجاد اطلاعیه جدید', 'reyhan-panel'); ?>
                </button>
            </div>

            <div id="rp-editor-wrapper" class="rp-editor-wrapper" style="display:none;">
                <div class="rp-editor-card">
                    <div class="rp-editor-header">
                        <div class="rp-ed-head-title">
                            <span class="dashicons dashicons-edit"></span> <span id="rp-editor-title"><?php esc_html_e('افزودن اطلاعیه', 'reyhan-panel'); ?></span>
                        </div>
                        <button type="button" id="rp-btn-cancel" class="rp-btn-close" title="<?php esc_attr_e('بستن', 'reyhan-panel'); ?>"><span class="dashicons dashicons-no-alt"></span></button>
                    </div>
                    <div class="rp-editor-body">
                        <div class="rp-row-grid-modern">
                            <div class="rp-field-group title-group">
                                <label><?php esc_html_e('عنوان اطلاعیه', 'reyhan-panel'); ?></label>
                                <div class="rp-input-icon-wrap">
                                    <input type="text" id="edit-title" class="rp-input-modern" placeholder="<?php esc_attr_e('مثال: جشنواره نوروزی...', 'reyhan-panel'); ?>">
                                </div>
                            </div>
                            <div class="rp-field-group type-group">
                                <label><?php esc_html_e('رنگ های اطلاعیه', 'reyhan-panel'); ?></label>
                                <div class="rp-select-wrap">
                                    <select id="edit-type" class="rp-input-modern">
                                        <option value="info"><?php esc_html_e('🔵 آبی (اطلاع‌رسانی)', 'reyhan-panel'); ?></option>
                                        <option value="success"><?php esc_html_e('🟢 سبز (موفقیت)', 'reyhan-panel'); ?></option>
                                        <option value="warning"><?php esc_html_e('🟡 زرد (هشدار)', 'reyhan-panel'); ?></option>
                                        <option value="danger"><?php esc_html_e('🔴 قرمز (خطر)', 'reyhan-panel'); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="rp-field-group">
                            <label><?php esc_html_e('متن کامل اطلاعیه', 'reyhan-panel'); ?></label>
                            <textarea id="edit-msg" rows="5" class="rp-input-modern" placeholder="<?php esc_attr_e('متن پیام خود را اینجا بنویسید...', 'reyhan-panel'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="rp-editor-footer">
                        <button type="button" id="rp-btn-save-item" class="rp-btn-save">
                            <span class="dashicons dashicons-saved"></span> <?php esc_html_e('ثبت اطلاعیه', 'reyhan-panel'); ?>
                        </button>
                        <span class="rp-hint"><span class="dashicons dashicons-info"></span> <?php printf( esc_html__('توجه کنید: بعد از زدن دکمه، اطلاعیه به تمامی کاربران در پنل کاربری نمایش داده میشود', 'reyhan-panel'), '<strong>'.__('ذخیره تغییرات نهایی', 'reyhan-panel').'</strong>' ); ?></span>
                    </div>
                </div>
            </div>

            <div id="rp-notif-grid" class="rp-notif-grid"></div>
            
            <div id="rp-empty-state" style="display:none;">
                <div class="rp-empty-icon"><span class="dashicons dashicons-megaphone"></span></div>
                <h3><?php esc_html_e('هیچ اطلاعیه‌ای وجود ندارد', 'reyhan-panel'); ?></h3>
                <p><?php esc_html_e('با زدن دکمه بالا، اولین اطلاعیه خود را بسازید.', 'reyhan-panel'); ?></p>
            </div>
        </div>

        <div id="rp_delete_modal" class="rp-logout-modal-overlay" style="display:none;">
    <div class="rp-logout-modal-box">
        <span class="dashicons dashicons-trash rp-logout-icon-large" style="color: #ef4444;"></span>
        <div class="rp-logout-title"><?php esc_html_e('حذف اطلاعیه', 'reyhan-panel'); ?></div>
        <div class="rp-logout-desc"><?php esc_html_e('آیا مطمئن هستید که می‌خواهید این اطلاعیه را حذف کنید؟ این عملیات غیرقابل بازگشت است.', 'reyhan-panel'); ?></div>
        
        <div class="rp-logout-actions">
            <button type="button" class="rp-btn-logout-no" id="rp-cancel-delete">
                <?php esc_html_e('خیر، انصراف', 'reyhan-panel'); ?>
            </button>
            <button type="button" class="rp-btn-logout-yes" id="rp-confirm-delete" style="background: #ef4444;">
                <?php esc_html_e('بله، حذف کن', 'reyhan-panel'); ?>
            </button>
        </div>
    </div>
</div>

    </form>
</div>