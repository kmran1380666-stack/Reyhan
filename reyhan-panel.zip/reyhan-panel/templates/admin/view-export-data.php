<?php defined('ABSPATH') || exit; ?>
<div class="wrap rp-wrap">
    <?php 
    // فراخوانی هدر استاندارد پلاگین
    if ( file_exists( \REYHAN_DIR . 'templates/admin/partials/admin-header.php' ) ) {
        include \REYHAN_DIR . 'templates/admin/partials/admin-header.php';
    } else {
        echo '<h1>' . esc_html__('استخراج داده (Export)', 'reyhan-panel') . '</h1>';
    }
    ?>
    <hr class="wp-header-end">

    <div class="rp-export-grid">
        <div class="rp-card rp-export-card">
            <h2><span class="dashicons dashicons-admin-users"></span> <?php esc_html_e('کاربران', 'reyhan-panel'); ?></h2>
            <p><?php esc_html_e('دریافت لیست کاربران سایت با فرمت CSV یا Excel', 'reyhan-panel'); ?></p>
            <div class="rp-export-options">
                <label><input type="checkbox" name="export_user_meta" checked> <?php esc_html_e('شامل شماره موبایل و آدرس', 'reyhan-panel'); ?></label>
            </div>
            <button type="button" class="button button-primary rp-do-export" data-type="users">
                <?php esc_html_e('دریافت خروجی کاربران', 'reyhan-panel'); ?>
            </button>
        </div>

        <div class="rp-card rp-export-card">
            <h2><span class="dashicons dashicons-tickets-alt"></span> <?php esc_html_e('تیکت‌ها', 'reyhan-panel'); ?></h2>
            <p><?php esc_html_e('آرشیو کامل تیکت‌ها و پاسخ‌های پشتیبانی', 'reyhan-panel'); ?></p>
            <div class="rp-export-options">
                <select class="rp-date-range">
                    <option value="all"><?php esc_html_e('همه زمان‌ها', 'reyhan-panel'); ?></option>
                    <option value="30days"><?php esc_html_e('۳۰ روز گذشته', 'reyhan-panel'); ?></option>
                    <option value="year"><?php esc_html_e('یک سال اخیر', 'reyhan-panel'); ?></option>
                </select>
            </div>
            <button type="button" class="button button-primary rp-do-export" data-type="tickets">
                <?php esc_html_e('دریافت خروجی تیکت‌ها', 'reyhan-panel'); ?>
            </button>
        </div>
        
        <div class="rp-card rp-export-card" style="opacity: 0.6;">
            <h2><span class="dashicons dashicons-cart"></span> <?php esc_html_e('سفارشات', 'reyhan-panel'); ?></h2>
            <p><?php esc_html_e('خروجی سفارشات ووکامرس (به زودی)', 'reyhan-panel'); ?></p>
            <button type="button" class="button button-secondary" disabled>
                <?php esc_html_e('غیرفعال', 'reyhan-panel'); ?>
            </button>
        </div>
    </div>
</div>