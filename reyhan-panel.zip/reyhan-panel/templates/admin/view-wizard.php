<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="rw-wrapper">
    <div class="rw-sidebar">
        <div class="rw-logo">
            <img src="<?php echo REYHAN_URL . 'assets/images/logo.png'; ?>" alt="Logo">
            <?php esc_html_e('افزونه جامع ریحان پنل', 'reyhan-panel'); ?>
        </div>
        
        <ul class="rw-steps">
            <li class="active" data-step="1"><span class="circle">1</span> <?php esc_html_e('لایسنس', 'reyhan-panel'); ?></li>
            <li data-step="2"><span class="circle">2</span> <?php esc_html_e('ووکامرس', 'reyhan-panel'); ?></li>
            <li data-step="3"><span class="circle">3</span> <?php esc_html_e('پیکربندی', 'reyhan-panel'); ?></li>
            <li data-step="4"><span class="circle">4</span> <?php esc_html_e('ظاهر', 'reyhan-panel'); ?></li>
            <li data-step="5"><span class="circle">5</span> <?php esc_html_e('پایان', 'reyhan-panel'); ?></li>
        </ul>

        <div>
            <a href="<?php echo admin_url('index.php'); ?>" class="rw-exit">
                <span class="dashicons dashicons-no-alt"></span> <?php esc_html_e('خروج از راه انداز', 'reyhan-panel'); ?>
            </a>
            <div style="font-size:11px; opacity:0.6; text-align:center; margin-top:15px;"><?php printf( esc_html__('نسخه %s', 'reyhan-panel'), REYHAN_VERSION ); ?></div>
        </div>
    </div>
    
    <form id="rw-form" class="rw-content">
        
        <div class="rw-step-content active" id="step-1">
            <h2><?php esc_html_e('به ریحان پنل خوش آمدید! 👋', 'reyhan-panel'); ?></h2>
            <p><?php esc_html_e('خیلی ممنون که ما رو انتخاب کردید! برای فعالسازی افزونه کد لایسنس رو در بخش پایین ثبت کنید.', 'reyhan-panel'); ?></p>
            
            <div class="rw-license-area">
                <div class="rw-license-head">
                    <span class="dashicons dashicons-lock"></span> <?php esc_html_e('فعال‌سازی لایسنس', 'reyhan-panel'); ?>
                </div>
                <div class="rw-license-form">
                    <input type="text" id="rw-license-input" class="rw-input" placeholder="XXXX-XXXX-XXXX-XXXX">
                    <button type="button" id="rw-check-license" class="rw-btn"><?php esc_html_e('بررسی لایسنس', 'reyhan-panel'); ?></button>
                </div>
                <div id="rw-license-msg" style="margin-top:10px; font-size:12px;"></div>
            </div>
        </div>

        <div class="rw-step-content" id="step-2">
            <h2><?php esc_html_e('بررسی ووکامرس', 'reyhan-panel'); ?></h2>
            <p><?php esc_html_e('یکپارچگی با فروشگاه‌ساز ووکامرس.', 'reyhan-panel'); ?></p>
            
            <?php if ( class_exists('WooCommerce') ): ?>
                <div style="background:#e8f5e9; border:1px solid #c8e6c9; padding:20px; border-radius:10px; text-align:center; margin-top:30px;">
                    <span class="dashicons dashicons-yes-alt" style="font-size:50px; width:50px; height:50px; color:#4caf50;"></span>
                    <h3 style="margin:10px 0; color:#2e7d32;"><?php esc_html_e('ووکامرس نصب و فعال است', 'reyhan-panel'); ?></h3>
                    <p style="color:#4caf50;"><?php esc_html_e('سیستم به طور خودکار با ووکامرس هماهنگ شد.', 'reyhan-panel'); ?></p>
                </div>
            <?php else: ?>
                <div style="background:#fff3e0; border:1px solid #ffe0b2; padding:20px; border-radius:10px; text-align:center; margin-top:30px;">
                    <span class="dashicons dashicons-info" style="font-size:50px; width:50px; height:50px; color:#ff9800;"></span>
                    <h3 style="margin:10px 0; color:#ef6c00;"><?php esc_html_e('ووکامرس نصب نیست', 'reyhan-panel'); ?></h3>
                    <p style="color:#f57c00; margin-bottom:20px;"><?php esc_html_e('برای تجربه بهتر کار با افزونه و مدیریت سفارشات، پیشنهاد می‌کنیم ووکامرس را نصب کنید. (اختیاری)', 'reyhan-panel'); ?></p>
                    <a href="<?php echo admin_url('plugin-install.php?s=woocommerce&tab=search&type=term'); ?>" target="_blank" class="rw-btn" style="background:#ff9800; border-color:#ff9800;">
                        <?php esc_html_e('نصب ووکامرس', 'reyhan-panel'); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div class="rw-step-content" id="step-3">
            <h2><?php esc_html_e('ساخت صفحات ضروری', 'reyhan-panel'); ?></h2>
            <p><?php esc_html_e('برای شروع کار، نیاز به یک برگه جهت "ورود و پنل کاربری" دارید.', 'reyhan-panel'); ?></p>
            
            <label class="rw-switch-box">
                <div class="rw-switch">
                    <input type="checkbox" name="create_page" value="1" checked>
                    <span class="rw-slider"></span>
                </div>
                <div class="rw-switch-label">
                    <strong><?php esc_html_e('ساخت خودکار برگه "پنل کاربری"', 'reyhan-panel'); ?></strong>
                    <span><?php esc_html_e('یک برگه جدید با شورت‌کد [reyhan_panel] ایجاد می‌شود.', 'reyhan-panel'); ?></span>
                </div>
            </label>
        </div>

        <div class="rw-step-content" id="step-4">
            <h2><?php esc_html_e('شخصی‌سازی ظاهر', 'reyhan-panel'); ?></h2>
            <p><?php esc_html_e('مشخصات ظاهری فرم ورود را تنظیم کنید.', 'reyhan-panel'); ?></p>
            
            <div class="rw-field">
                <label class="rw-label"><?php esc_html_e('آپلود لوگو (نمایش در فرم ورود)', 'reyhan-panel'); ?></label>
                <div class="rw-upload-area" id="rw-upload-trigger">
                    <span class="dashicons dashicons-cloud-upload rw-upload-icon"></span>
                    <span class="rw-upload-text"><?php esc_html_e('برای انتخاب تصویر کلیک کنید', 'reyhan-panel'); ?></span>
                    <img src="" class="rw-preview-img" id="rw-logo-preview">
                    <input type="hidden" name="login_logo" id="rw-logo-input">
                </div>
            </div>
            
            <div class="rw-field">
                <label class="rw-label"><?php esc_html_e('عنوان صفحه ورود', 'reyhan-panel'); ?></label>
                <input type="text" name="login_title" class="rw-input" placeholder="<?php esc_attr_e('مثال: ورود به حساب کاربری', 'reyhan-panel'); ?>" value="<?php esc_attr_e('ورود به حساب کاربری', 'reyhan-panel'); ?>">
            </div>
        </div>

        <div class="rw-step-content" id="step-5">
            <div style="text-align:center; padding-top:40px;">
                <span style="font-size:70px;">🎉</span>
                <h2 style="margin-top:40px;"><?php esc_html_e('همه‌چیز آماده است!', 'reyhan-panel'); ?></h2>
                <p><?php esc_html_e('تنظیمات اولیه با موفقیت انجام شد. اکنون می‌توانید وارد پنل تنظیمات شده و جزئیات بیشتری را مدیریت کنید.', 'reyhan-panel'); ?></p>
                <br>
                <a href="<?php echo admin_url('admin.php?page=reyhan-settings'); ?>" class="rw-btn"><?php esc_html_e('ورود به تنظیمات افزونه', 'reyhan-panel'); ?></a>
            </div>
        </div>

        <div class="rw-footer" id="rw-footer-nav">
            <button type="button" class="rw-btn rw-btn-outline" id="btn-prev" style="display:none;"><?php esc_html_e('مرحله قبل', 'reyhan-panel'); ?></button>
            <button type="button" class="rw-btn" id="btn-next"><?php esc_html_e('مرحله بعد', 'reyhan-panel'); ?></button>
        </div>

    </form>
</div>