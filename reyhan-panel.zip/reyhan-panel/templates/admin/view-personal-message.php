<?php defined('ABSPATH') || exit; ?>
<div class="wrap rp-wrap">
    <?php 
    if ( file_exists( \REYHAN_DIR . 'templates/admin/partials/admin-header.php' ) ) {
        include \REYHAN_DIR . 'templates/admin/partials/admin-header.php';
    } 
    ?>
    
    <div class="rp-app-container">
        
        <div class="rp-app-sidebar">
            <div class="rp-sidebar-actions">
                <button type="button" class="button button-primary rp-btn-block" id="btn-new-msg">
                    <span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e('نوشتن پیام جدید', 'reyhan-panel'); ?>
                </button>
            </div>
            
            <div class="rp-msg-list-wrapper">
                <h3 class="rp-sidebar-title"><?php esc_html_e('پیام‌های ارسال شده', 'reyhan-panel'); ?></h3>
                <ul class="rp-msg-list" id="rp-sent-list">
                    <li class="rp-empty-state-sidebar" style="padding: 20px; text-align: center; color: #999;">
                        <span class="dashicons dashicons-email-alt" style="font-size: 30px; margin-bottom: 10px; display: block; width: auto; height: auto;"></span>
                        <small><?php esc_html_e('پیامی یافت نشد', 'reyhan-panel'); ?></small>
                    </li>
                </ul>
            </div>
        </div>

        <div class="rp-app-content">
            <div class="rp-card-v2-body">
                
                <div class="rp-search-user-box" style="position: relative;">
                    <label class="rp-section-label" id="rp-search-label" for="rp-user-search-input">
                        <?php esc_html_e('کاربر مورد نظر خود را جستجو کنید', 'reyhan-panel'); ?>
                    </label>
                    
                    <div class="rp-modern-input-wrap">
                        <input type="text" id="rp-user-search-input" class="rp-input-modern rp-clean-input" 
                               placeholder="<?php esc_attr_e('ایمیل - شماره همراه - نام و نام خانوادگی', 'reyhan-panel'); ?>" 
                               autocomplete="off">
                        <span class="dashicons dashicons-search rp-input-icon" style="position:absolute; left: 10px; top: 12px; color:#ccc;"></span>
                        <div id="rp-user-search-results" class="rp-search-dropdown" style="display:none;"></div>
                    </div>
                    
                    <input type="hidden" id="selected_user_id" name="user_id" value="">
                </div>

                <div id="rp-user-info-card" class="rp-user-info-card" style="display:none; animation: fadeIn 0.3s;">
                    <div class="rp-u-avatar">
                        <img id="u-img" src="" alt="User Avatar">
                    </div>
                    <div class="rp-u-details">
                        <h3 id="u-name"></h3>
                        <div class="rp-u-meta">
                            <span class="rp-badge-meta"><span class="dashicons dashicons-smartphone"></span> <span id="u-mobile">---</span></span>
                            <span class="rp-badge-meta"><span class="dashicons dashicons-email"></span> <span id="u-email">---</span></span>
                        </div>
                    </div>
                    <div class="rp-u-actions">
                        <button type="button" id="btn-change-user" class="button button-small rp-btn-outline">
                            <?php esc_html_e('تغییر کاربر', 'reyhan-panel'); ?>
                        </button>
                    </div>
                </div>

                <hr class="rp-divider">

                <form id="rp-personal-msg-form" style="width: 100%;">
                    <div class="rp-form-row">
                        <div class="rp-col-12" style="width: 100%;">
                            <label class="rp-section-label"><?php esc_html_e('عنوان پیام', 'reyhan-panel'); ?></label>
                            <input type="text" id="msg-title" name="title" class="rp-input-modern full-width" placeholder="<?php esc_attr_e('موضوع پیام را بنویسید...', 'reyhan-panel'); ?>">
                        </div>
                    </div>

                    <div class="rp-form-row">
                        <div class="rp-col-12" style="width: 100%;">
                            <label class="rp-section-label"><?php esc_html_e('متن پیام', 'reyhan-panel'); ?></label>
                            <textarea id="msg-content" name="content" class="rp-input-modern full-width" rows="12" placeholder="<?php esc_attr_e('متن کامل پیام خود را اینجا بنویسید...', 'reyhan-panel'); ?>"></textarea>
                        </div>
                    </div>

                    <div class="rp-form-footer">
                        <div class="rp-toggle-wrapper">
                            <label class="rp-switch-gradient-box">
                                <input type="checkbox" id="send_email_check" name="send_email" value="1">
                                <span class="rp-slider-gradient"></span>
                            </label>
                            <span class="rp-toggle-label"><?php esc_html_e('ارسال ایمیل اطلاع‌رسانی', 'reyhan-panel'); ?></span>
                        </div>

                        <button type="submit" class="button button-primary button-large rp-btn-send">
                            <?php esc_html_e('ارسال پیام', 'reyhan-panel'); ?> <span class="dashicons dashicons-arrow-left-alt"></span>
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div id="rp-reset-confirm-modal" class="rp-modal-overlay" style="display:none;">
        <div class="rp-modal-box-mini">
            <div class="rp-modal-icon-box danger">
                <span class="dashicons dashicons-warning"></span>
            </div>
            <h3 class="rp-modal-title"><?php esc_html_e('آیا مطمئن هستید؟', 'reyhan-panel'); ?></h3>
            <p class="rp-modal-desc"><?php esc_html_e('شما اطلاعاتی را وارد کرده‌اید که هنوز ذخیره نشده است. با ایجاد پیام جدید، تمام این اطلاعات پاک می‌شود.', 'reyhan-panel'); ?></p>
            <div class="rp-modal-actions">
                <button type="button" class="rp-btn-modal cancel" id="btn-modal-cancel"><?php esc_html_e('انصراف', 'reyhan-panel'); ?></button>
                <button type="button" class="rp-btn-modal confirm" id="btn-modal-confirm"><?php esc_html_e('بله، پاک کن', 'reyhan-panel'); ?></button>
            </div>
        </div>
    </div>
</div>