<?php defined('ABSPATH') || exit; ?>
<div class="wrap rp-wrap">
    <?php 
    if ( file_exists( \REYHAN_DIR . 'templates/admin/partials/admin-header.php' ) ) {
        include \REYHAN_DIR . 'templates/admin/partials/admin-header.php';
    } 
    ?>
    
    <div class="rp-app-container">
        <div class="rp-app-sidebar">
            <div class="rp-sidebar-actions">
                <button type="button" class="button button-primary rp-btn-block" id="btn-new-msg">
                    <span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e('نوشتن پیام جدید', 'reyhan-panel'); ?>
                </button>
            </div>
            
            <div class="rp-msg-list-wrapper">
                <h3 class="rp-sidebar-title"><?php esc_html_e('پیام‌های ارسال شده', 'reyhan-panel'); ?></h3>
                <ul class="rp-msg-list" id="rp-sent-list">
                    <li class="rp-msg-item active">
                        <div class="rp-msg-avatar">
                            <img src="<?php echo \REYHAN_URL; ?>assets/images/user.png" alt="User">
                        </div>
                        <div class="rp-msg-info">
                            <span class="rp-msg-name">علی محمدی</span>
                            <span class="rp-msg-date">2 ساعت پیش</span>
                            <span class="rp-msg-excerpt">سلام، در مورد تیکت...</span>
                        </div>
                    </li>
                    <li class="rp-msg-item">
                        <div class="rp-msg-avatar">
                            <img src="<?php echo \REYHAN_URL; ?>assets/images/user.png" alt="User">
                        </div>
                        <div class="rp-msg-info">
                            <span class="rp-msg-name">رضا کریمی</span>
                            <span class="rp-msg-date">دیروز</span>
                            <span class="rp-msg-excerpt">کد تخفیف شما منقضی...</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

        <div class="rp-app-content">
            <div class="rp-card-v2-body">
                
                <div class="rp-search-user-box">
                    <label class="rp-section-label"><?php esc_html_e('گیرنده پیام', 'reyhan-panel'); ?></label>
                    <select id="rp-user-select" class="rp-select2-users" style="width: 100%;">
                        <option value=""><?php esc_html_e('جستجوی کاربر (نام، ایمیل، موبایل...)', 'reyhan-panel'); ?></option>
                    </select>
                </div>

                <div id="rp-user-info-card" class="rp-user-info-card" style="display:none;">
                    <div class="rp-u-avatar">
                        <img id="u-img" src="" alt="">
                    </div>
                    <div class="rp-u-details">
                        <h3 id="u-name"></h3>
                        <div class="rp-u-meta">
                            <span class="rp-badge-meta"><span class="dashicons dashicons-smartphone"></span> <span id="u-mobile"></span></span>
                            <span class="rp-badge-meta"><span class="dashicons dashicons-email"></span> <span id="u-email"></span></span>
                        </div>
                    </div>
                    <div class="rp-u-actions">
                        <a href="#" id="u-link" target="_blank" class="button button-small"><?php esc_html_e('مشاهده پروفایل', 'reyhan-panel'); ?></a>
                    </div>
                </div>

                <hr class="rp-divider">

                <form id="rp-personal-msg-form">
                    <div class="rp-form-row">
                        <div class="rp-col-12">
                            <label class="rp-section-label"><?php esc_html_e('عنوان پیام', 'reyhan-panel'); ?></label>
                            <input type="text" name="title" class="rp-input-modern rp-clean-input" placeholder="<?php esc_attr_e('موضوع پیام را بنویسید...', 'reyhan-panel'); ?>">
                        </div>
                    </div>

                    <div class="rp-form-row">
                        <div class="rp-col-12">
                            <label class="rp-section-label"><?php esc_html_e('متن پیام', 'reyhan-panel'); ?></label>
                            <textarea name="content" class="rp-input-modern" rows="10" placeholder="<?php esc_attr_e('متن کامل پیام خود را اینجا بنویسید...', 'reyhan-panel'); ?>"></textarea>
                        </div>
                    </div>

                    <div class="rp-form-footer">
                        <div class="rp-send-options">
                            <label><input type="checkbox" name="send_sms"> <?php esc_html_e('ارسال پیامک اطلاع‌رسانی', 'reyhan-panel'); ?></label>
                            <label><input type="checkbox" name="send_email"> <?php esc_html_e('ارسال ایمیل', 'reyhan-panel'); ?></label>
                        </div>
                        <button type="submit" class="button button-primary button-large rp-btn-send">
                            <?php esc_html_e('ارسال پیام', 'reyhan-panel'); ?> <span class="dashicons dashicons-arrow-left-alt"></span>
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>