<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="wrap reyhanpanel-wrap">
    <div class="rp-header-hero">
        <div class="rp-hero-icon-box">
            <span class="dashicons dashicons-admin-settings"></span>
        </div>
        <div class="rp-hero-content">
            <h1><?php esc_html_e('تنظیمات عمومی', 'reyhan-panel'); ?></h1>
            <p><?php esc_html_e('مدیریت تنظیمات اصلی، درگاه‌های پیامک و ایمیل', 'reyhan-panel'); ?></p>
        </div>
    </div>
    
    <?php 
    if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
        echo '<div id="reyhan-toast-msg" class="rp-modern-toast"><span class="dashicons dashicons-saved"></span> <span>'.esc_html__('تغییرات با موفقیت ذخیره شد.', 'reyhan-panel').'</span></div>';
    }
    ?>

    <form method="post" action="options.php">
        <?php settings_fields('reyhan_master_group'); ?>
        
        <div class="rp-settings-container"> 
            <div class="rp-settings-sidebar">
                <div class="rp-sidebar-logo"><img src="<?php echo REYHAN_URL . 'assets/images/logo.png'; ?>" alt="Logo"></div>
                <ul class="rp-tabs-nav" id="rp-main-nav">
                    <li class="active" data-tab="tab-login"><span class="dashicons dashicons-admin-users"></span> <?php esc_html_e('ورود و عضویت', 'reyhan-panel'); ?></li>
                    <li data-tab="tab-sms"><span class="dashicons dashicons-smartphone"></span> <?php esc_html_e('پیامک پنل کاربری', 'reyhan-panel'); ?></li>
                    <li data-tab="tab-email"><span class="dashicons dashicons-email"></span> <?php esc_html_e('ایمیل پنل کاربری', 'reyhan-panel'); ?></li>
                    <li data-tab="tab-ticket"><span class="dashicons dashicons-tickets-alt"></span> <?php esc_html_e('تنظیمات تیکت', 'reyhan-panel'); ?></li>
                    <li data-tab="tab-security"><span class="dashicons dashicons-shield"></span> <?php esc_html_e('امنیت', 'reyhan-panel'); ?></li>
                    <li data-tab="tab-tools"><span class="dashicons dashicons-admin-tools"></span> <?php esc_html_e('ابزارها', 'reyhan-panel'); ?></li>
                </ul>
                <div class="rp-save-box">
                    <?php submit_button(__('ذخیره تغییرات', 'reyhan-panel'), 'primary', 'submit', false); ?>
                    <div class="rp-version-info"><?php printf( esc_html__('نسخه %s', 'reyhan-panel'), REYHAN_VERSION ); ?></div>
                </div>
            </div> 
            
            <div class="rp-settings-content">
                
                <div id="tab-login" class="rp-tab-pane active">
                    <h2><?php esc_html_e('تنظیمات ورود و عضویت', 'reyhan-panel'); ?></h2>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_login'); ?></table>
                </div>

                <div id="tab-sms" class="rp-tab-pane">
                    <h2><?php esc_html_e('تنظیمات پیامک', 'reyhan-panel'); ?></h2>
                    
                    <div class="rp-sms-status-widget" style="background: #f0f9ff; border: 1px solid #b3e5fc; border-radius: 10px; padding: 20px; margin-bottom: 25px; display: flex; align-items: center; justify-content: space-between;">
                        <div class="rp-sms-stat-info">
                            <h4 style="margin: 0 0 5px 0; font-size: 15px; color: #0277bd;">
                                <span class="dashicons dashicons-cloud" style="vertical-align: middle;"></span> 
                                <?php esc_html_e('وضعیت اتصال به پنل پیامک', 'reyhan-panel'); ?>
                            </h4>
                            <div id="rp-sms-balance-display" style="font-size: 13px; color: #555;">
                                <?php esc_html_e('برای مشاهده اعتبار و وضعیت، روی دکمه تست کلیک کنید.', 'reyhan-panel'); ?>
                            </div>
                        </div>
                        <div class="rp-sms-stat-action">
                            <button type="button" id="btn-check-sms-connection" class="button button-secondary" style="border-color: #0277bd; color: #0277bd;">
                                <span class="dashicons dashicons-update" style="vertical-align: middle;"></span>
                                <?php esc_html_e('تست اتصال و دریافت اعتبار', 'reyhan-panel'); ?>
                            </button>
                        </div>
                    </div>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_sms'); ?></table>
                </div>

                <div id="tab-email" class="rp-tab-pane">
                    <h2><?php esc_html_e('تنظیمات ایمیل', 'reyhan-panel'); ?></h2>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_email'); ?></table>
                </div>

                <div id="tab-ticket" class="rp-tab-pane">
                    <h2><?php esc_html_e('تنظیمات تیکت', 'reyhan-panel'); ?></h2>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_ticket'); ?></table>
                </div>

                <div id="tab-security" class="rp-tab-pane">
                    <h2><?php esc_html_e('تنظیمات امنیتی', 'reyhan-panel'); ?></h2>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_security'); ?></table>
                </div>

                <div id="tab-tools" class="rp-tab-pane">
                    <h2><?php esc_html_e('ابزارها', 'reyhan-panel'); ?></h2>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_tools'); ?></table>
                </div>

            </div> 
        </div> 
    </form>
</div>